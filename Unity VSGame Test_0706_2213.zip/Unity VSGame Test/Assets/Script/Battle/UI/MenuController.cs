﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//メニュー管理
//--------------------------------------------------------------------------
public class MenuController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    GameObject  menuObj;    //メニューに使うObject
    bool        isStart;    //一回だけ処理するためのフラグ

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //接続
        this.menuObj = GameObject.Find("MenuCanvas");
        this.isStart = true;
        Menu(false);
    }

    // Update is called once per frame
    void Update()
    {

        if (BattleDirector.endState != BattleDirector.EndState.None)
        {
            //一回だけ処理
            if (this.isStart)
            {
                Menu(false);
                this.isStart = false;
            }
        }

    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //メニューで行えるボタンの処理
    //--------------------------------------------------------------------------
    //メニューモードのON:OFF
    public void Menu(bool isFlag)
    {
        //ゲーム終了後は強制メニューOFF
        if (BattleDirector.endState != BattleDirector.EndState.None) { isFlag = false; }

        BattleDirector.isMenu = isFlag;
        this.menuObj.SetActive(isFlag);

        Debug.Log("Menu:" + isFlag);
    }

    //ゲーム終了（アプリケーション終了）
    public void GameQuit()
    {
        //保存するものはここで処理しておく

        Debug.Log("ゲーム終了");
        Application.Quit();
    }
}
