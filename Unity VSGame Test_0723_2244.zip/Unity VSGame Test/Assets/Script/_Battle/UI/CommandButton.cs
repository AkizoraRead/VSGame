﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//プレイヤーのコマンドボタン操作
//--------------------------------------------------------------------------
public class CommandButton : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    Button[]    cButton;        //コマンド操作に使われるボタン
    bool        preIsGame;      //前フレームとのフラグの違いを判定するためのフラグ

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //ボタンの設定
        this.cButton = new Button[transform.childCount];
        for(int i = 0;i < transform.childCount;i++)
        {
            this.cButton[i] = transform.GetChild(i).gameObject.GetComponent<Button>();
        }

        ButtonChange(BattleDirector.isGaming);
        this.preIsGame = BattleDirector.isGaming;
    }

    // Update is called once per frame
    void Update()
    {
        if(BattleDirector.turnState != BattleDirector.TurnState.InGame) { return; }
        if (this.preIsGame == BattleDirector.isGaming) { return; }

        ButtonChange(BattleDirector.isGaming);
    }

    //--------------------------------------------------------------------------
    //ボタンの有効・無効化
    //引数（有効 or 無効）
    void ButtonChange(bool isFlag)
    {
        foreach(Button button in this.cButton)
        {
            button.enabled = isFlag;
        }

        this.preIsGame = isFlag;    //フラグの記録の更新
    }
}
