﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//音源のロードと設定をするクラス
//--------------------------------------------------------------------------
public class SoundReader : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    //音源を格納する変数
    Dictionary<string, AudioClip> soundTable = new Dictionary<string, AudioClip>();
    //音源名
    [SerializeField] string[] soundName = new string[] { };
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        foreach (string name in this.soundName)
        {
            SoundLoad(name);
        }
    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
    //音源をリソースファイルからロードする
    //引数（音源名）
    void SoundLoad(string name)
    {
        //読み込み
        try
        {
            AudioClip audioClip = Resources.Load<AudioClip>("Sound/" + name);
            //セット
            this.soundTable[name] = audioClip;

            Debug.Log("音源を読み込み成功：" + name);
        }
        //エラー処理
        catch (System.Exception e_)
        {
            Debug.LogWarning(e_.Message);
            Debug.LogWarning("音源を読み込めませんでした：" + name);
        }
    }
    //--------------------------------------------------------------------------
    //使う音源を返す
    //引数（音源名）
    public AudioClip Sound(string name)
    {
        try
        {
            AudioClip audioClip = this.soundTable[name];
            return audioClip;
        }
        catch(System.Exception e_)
        {
            Debug.LogWarning(e_.Message);
            Debug.LogWarning("音源はありません：" + name);
            return null;
        }
    }
    //--------------------------------------------------------------------------

}
