﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//タイトルロゴの挙動
//--------------------------------------------------------------------------
public class TitleLogoImage : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //状態
    enum State { Start,End}
    //--------------------------------------------------------------------------
    //フィールド

    State state;    //状態
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.state = State.Start;
        transform.position = new Vector2(Screen.width / 2.0f, Screen.height);
    }

    void Update()
    {
        //初期動作
        if(this.state == State.Start)
        {
            //予定位置まで移動
            if (transform.position.y > Screen.height / 5.0f * 3.0f)
            {
                transform.position += new Vector3(0,  -100.0f * Time.deltaTime, 0.0f);
            }
            //完了後、次の状態へ
            else
            {
                this.state = State.End;
            }
        }
        else
        {

        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
