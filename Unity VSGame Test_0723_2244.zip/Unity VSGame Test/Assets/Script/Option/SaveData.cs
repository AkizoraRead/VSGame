﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveData
{

    //Json形式にpublic,[SerializeField]の変数を変換
    //引数（保存するクラス）
    string DataToJson<T>(T data)
    {
        return JsonUtility.ToJson(data);
    }
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    //引数(格納するデータ名,保存するクラス)
    public void DataSave<T>(string name,T data)
    {
        PlayerPrefs.SetString(name, DataToJson(data));
        PlayerPrefs.Save();
        Debug.Log("保存完了");
    }

    //--------------------------------------------------------------------------
    //ロード(PlayerPrefから読み込み) (true:成功)
    //引数（保存した名,上書きするクラス）
    public void DataLoad<T> (string name , ref T data)
    {
        //未入力の場合、処理せず
        if(data == null) { return; }

        //nameという名のデータが保存されているか
        if (PlayerPrefs.HasKey(name))
        {
            //上書き
            var loaddata = PlayerPrefs.GetString(name);
            JsonUtility.FromJsonOverwrite(loaddata, data);
            Debug.Log("ロード成功:" + data.ToString() + name);
            Debug.Log(loaddata);
        }
        //データがない場合
        else
        {
            Debug.LogWarning(name + "という名のデータは保存されていませんでした。\n新規作成します。");
        }
        //セッティング(読み込みだけでは変わらない部分を初期化する)

    }

}
