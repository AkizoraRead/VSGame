﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor.VersionControl;
using UnityEngine;
using UnityEngine.UIElements;

//--------------------------------------------------------------------------
//ハイスコアの保存
//--------------------------------------------------------------------------
public class ScoreData : SaveData
{
    //--------------------------------------------------------------------------
    public int[]    stageScore; //ステージ毎のスコア

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    public ScoreData()
    {
        this.stageScore = new int[BattleDirector.stageLimit];
        //データ初期化
        for (int i = 0; i < this.stageScore.Length; i++)
        {
            this.stageScore[i] = 0;
        }

    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    //引数(スコア)
    public void Save(int score)
    {
        //登録された値より大きければスコア更新
        if (this.stageScore[BattleDirector.stageNum] < score)
        {
            this.stageScore[BattleDirector.stageNum] = score;
            Debug.Log("ステージスコアを更新しました:Stage" + BattleDirector.stageNum);
        }
        else
        {
            Debug.Log("ステージスコアを更新しません:Stage" + BattleDirector.stageNum);
        }

        DataSave("ScoreData",this);  //スコアデータ保存
    }

    //--------------------------------------------------------------------------
    //ロードしたデータ返す(PlayerPrefから読み込み)
    public ScoreData Load()
    {
        //保存してあるデータを受け取る
        ScoreData data = new ScoreData();
        DataLoad("ScoreData", ref data); //

        return data;
    }
    //--------------------------------------------------------------------------
}
