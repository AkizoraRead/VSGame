﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//タイトルでの処理を統括するスクリプト
//--------------------------------------------------------------------------
public class TitleDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    OptionDirector optionClass; //よく使う機能が入ったクラス


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.optionClass = GameObject.Find("OptionDirector").GetComponent<OptionDirector>();

    }

    void Update()
    {
        if (this.optionClass.touchClass.CheckTouch()) 
        {
            //入力無効のときは処理せず
            if (!OptionDirector.isInput) { return; }

            //SE再生
            SEController seClass = GameObject.Find("SEController").GetComponent<SEController>();
            seClass.SE_Play("System01");

            //シーン変更
            this.optionClass.sceneClass.NextScene("SelectScene");

            //入力受付無効化
            OptionDirector.isInput = false;
        }
    }
    //--------------------------------------------------------------------------
}
