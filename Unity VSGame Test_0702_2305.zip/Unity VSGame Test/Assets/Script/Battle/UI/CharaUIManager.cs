﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharaUIManager : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラクターごとのUI操作クラス
    //--------------------------------------------------------------------------
    //フィールド

    //キャラクターが使うUIを操作するクラス
    Canvas uiCanvas;    //UIを表示するためのCanvas


    //キャラクターで必要なUIクラス
    UIGenerator uiGenerator;    //HPゲージUIクラス



    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //クラスの接続
        this.uiGenerator = GameObject.Find("Generator").GetComponent<UIGenerator>();

        //オブジェクト設定
        this.uiCanvas = GameObject.Find("CharaUICanvas").GetComponent<Canvas>();

        //HPゲージ生成
        this.uiGenerator.CreateCharaHPGauge(gameObject,this.uiCanvas);
    }

    // Update is called once per frame
    void Update()
    {

    }
    //--------------------------------------------------------------------------

}
