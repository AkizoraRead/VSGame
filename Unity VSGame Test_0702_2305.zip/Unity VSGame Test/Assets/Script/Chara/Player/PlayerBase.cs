﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBase : CharaBase
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤー固有のパラメータや関数
    //--------------------------------------------------------------------------
    //コンストラクタ
    public PlayerBase(GameObject go):base("PlayerData")
    {
        //プレイヤー固有の変更
        this.param.CType = CharaParameter.CharaType.Player;
        ComponentSetting(go);
        ColorChange(this.param.color);    //色替え
    }

    //--------------------------------------------------------------------------
    //キャラの色変更
    public void ColorChange(Color color_)
    {
        this.param.color = color_;
        this.sprite.color = color_;
    }

    //--------------------------------------------------------------------------

}
