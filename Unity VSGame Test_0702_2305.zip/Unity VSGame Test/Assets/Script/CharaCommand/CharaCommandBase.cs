﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//コマンドの基礎クラス
public abstract class CharaCommandBase
{
    //コマンド処理
    public delegate void Command(ref CharaParameter param_);

    //コマンドの種類
    public enum CommandType
    {
        None,       //未設定
        Attack,     //攻撃
        Recover,    //回復
        Enhance,    //強化
    }


    //コマンドデータ
    public struct CommandData
    {
        public CommandType cType;   //コマンドの種類
        public Command command; //関数
        public string cName;    //コマンド名
        public string[] cLog;   //コマンドの詳細
    }
    //--------------------------------------------------------------------------
    //共通変数
    protected string[] cdName;
    public Dictionary<string, CommandData> cData;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    protected CharaCommandBase()
    {
        this.cData = new Dictionary<string, CommandData>();
    }


    //--------------------------------------------------------------------------
    //コマンドデータ初期化
    //引数（コマンド名,コマンドタイプ）
    protected CommandData CommandDataSet(string name_, CommandType type)
    {
        CommandData data_;
        data_.cType = type;
        data_.command = CommandSet(name_);
        data_.cName = name_;
        data_.cLog = CommandLogSet(name_, data_.cType);
        return data_;
    }
    //--------------------------------------------------------------------------
    //コマンド処理を設定
    //引数(コマンド名)
    protected abstract Command CommandSet(string name_);

    //--------------------------------------------------------------------------
    //コマンド詳細を設定
    //引数(コマンド名)
    string[] CommandLogSet(string cName_,CommandType type)
    {
        //テキスト読み込み
        TextLoad textLoadClass = new TextLoad();
        string[] log = textLoadClass.GetText_CommandLog(cName_,type);
        return log;
    }

    //--------------------------------------------------------------------------
    //コマンドの詳細を返す
    //引数(コマンド名)
    public string GetCommandLog(string cName_)
    {
        string log = "";

        //ログ入力
        log += cData[cName_].cName + "\n";                  //コマンド名

        for (int i = 0; i < cData[cName_].cLog.Length; i++) 
        {
            log += cData[cName_].cLog[i] + "\n";            //コマンドの説明(行ごと)
        }

        //ログ出力
        return log;
    }
    //--------------------------------------------------------------------------

}
//--------------------------------------------------------------------------
//キャラクターのコマンド
public interface CharaCommand
{
    //選べるコマンド
    void Command1();
    void Command2();
    void Command3();
    void Damage(CharaParameter param_);      //ダメージ処理
}
