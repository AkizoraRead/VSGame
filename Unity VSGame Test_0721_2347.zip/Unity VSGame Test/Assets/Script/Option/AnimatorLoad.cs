﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatorLoad 
{
    //--------------------------------------------------------------------------
    //フィールド

    RuntimeAnimatorController anim;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    public AnimatorLoad()
    {
        this.anim = null;

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //アニメーターコントローラーを読み込んで返す
    public RuntimeAnimatorController GetAnimatorController(CharaParameter.CharaType cType,int num)
    {
        //パスの設定
        string path = "Chara/" + cType.ToString() + "/" + num.ToString();

        //読み込み
        LoadAnimatorController(path);

        return this.anim;
    }
    //--------------------------------------------------------------------------
    //リソースからアニメーターコントローラーを読み込む
    void LoadAnimatorController(string path)
    {
        try
        {
            this.anim = Resources.Load("Animation/" + path) as RuntimeAnimatorController;
        }
        catch(System.Exception e_)
        {
            Debug.Log(e_.Message);
            Debug.Log("ロード失敗：RuntimeAnimatorController" + "\n" + "パス:" + path);
        }
    }
    //--------------------------------------------------------------------------
}
