﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//バトルログの表示
//--------------------------------------------------------------------------
public class BattleLog : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    bool isFull;        //ログ表示の状態(全体・縮小)
    int preLineCnt;     //前フレームでのログの行数

    RectTransform rect; //パネルの表示領域
    Text logText;       //ログ表示のテキスト
    Button logButton;   //ログの表示状態を変えるボタン

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.isFull = false;
        this.preLineCnt = 0;
        this.rect = GetComponent<RectTransform>();
        this.logText = transform.Find("LogText").GetComponent<Text>();
        this.logButton = transform.Find("LogButton").GetComponent<Button>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.O)) { LogTypeChange(); }

        //ログの行数が変わっていなければ処理せず
        if(this.preLineCnt == BattleDirector.battleLog.Count) { return; }

        //ログ更新
        LogText_Update(BattleDirector.battleLog.Count);

    }

    //--------------------------------------------------------------------------
    //ログ表示変更
    public void LogTypeChange()
    {
        //状態の切り替え
        this.isFull = !this.isFull;

        //ログ範囲調整(フル)
        if (this.isFull)
        {
            //パネルの範囲
            rect.localPosition = new Vector2(-275, 0);
            rect.sizeDelta = new Vector2(rect.sizeDelta.x, 500);
            //テキストの範囲
            this.logText.gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(250, 490);
        }
        //ログ範囲調整(通常)
        else
        {
            //パネルの範囲
            rect.localPosition = new Vector2(-275, -200);
            rect.sizeDelta = new Vector2(rect.sizeDelta.x, 100);
            //テキストの範囲
            this.logText.gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(250, 85);
        }
        //ボタンの範囲
        this.logButton.gameObject.GetComponent<RectTransform>().sizeDelta = rect.sizeDelta;

        //ログ更新
        LogText_Update(BattleDirector.battleLog.Count);

    }

    //--------------------------------------------------------------------------
    //ログテキストの更新
    //引数（ログの全行数）
    void LogText_Update(int logLineCnt)
    {
        //ログテキスト表示
        string log = "";

        //表示する行数    (テキストの高さ / (フォントサイズ + 行間))
        int lineCnt_ = (int)(this.logText.gameObject.GetComponent<RectTransform>().sizeDelta.y / (this.logText.fontSize + this.logText.lineSpacing));

        //ログテキスト表示（最新のログを表示する）
        for (int i = logLineCnt - lineCnt_;
            i < logLineCnt;
            i++)
        {
            if (i < 0) { continue; }
            log += BattleDirector.battleLog[i] + "\n";
        }

        this.logText.text = log;

        this.preLineCnt = logLineCnt;   //行数の記録の更新
    }
    //--------------------------------------------------------------------------
}
