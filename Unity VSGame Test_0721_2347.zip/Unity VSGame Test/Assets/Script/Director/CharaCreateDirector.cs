﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//キャラクリエイト画面での統括
//--------------------------------------------------------------------------
public class CharaCreateDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    void Start()
    {
        ClearData clearData = new ClearData().Load();


        //初回のみ説明あり
        if(clearData.isCharaCreate)
        {


            //次回以降説明なし
            clearData.isCharaCreate = false;
            clearData.Save();
        }

    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------



}
