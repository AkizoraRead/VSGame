﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//スコアをテキストに表示
//--------------------------------------------------------------------------
public class ScoreCanvas : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    ScoreData   scoreData;      //スコアデータ
    Text[]      scoreText;      //スコア表示するテキスト
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {

        //スコアデータを読み込む
        this.scoreData = new ScoreData().Load();


        //テキストの初期化
        this.scoreText = new Text[BattleDirector.stageLimit];
        for (int i = 0; i < BattleDirector.stageLimit; i++)
        {
            //設定
            this.scoreText[i] = transform.GetChild(i).transform.GetChild(0).transform.GetComponent<Text>();

            string msg = "";
            if (i != 0) { msg = "ステージ" + i + "\n\n"; }
            else        { msg = "チュートリアル" + "\n\n"; }   //チュートリアルステージの場合

            //スコア表示
            this.scoreText[i].text = msg + this.scoreData.stageScore[i];

        }
    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
}
