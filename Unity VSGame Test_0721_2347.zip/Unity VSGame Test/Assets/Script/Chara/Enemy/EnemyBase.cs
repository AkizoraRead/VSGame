﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using UnityEngine;

//--------------------------------------------------------------------------
//エネミー固有のパラメータや関数
//--------------------------------------------------------------------------
public class EnemyBase : CharaBase
{
    //--------------------------------------------------------------------------
    //エネミーに必要なデータ
    struct EnemyData
    {
        public string   name;           //キャラ名
        public int      hp;             //最大HP
        public int      power;          //攻撃力
        public int      dodgeRate;      //回避率
        public string   attackName;     //攻撃コマンド名
        public string   recoverName;    //回復コマンド名
        public string   enhanceName;    //強化コマンド名
        public int      level;          //敵のレベル
        public int      animType;       //絵の種類
    }
    //--------------------------------------------------------------------------
    //フィールド

    EnemyData   eData;  //読み込むデータ構造体
    int         level;  //敵のレベル
    //--------------------------------------------------------------------------
    //プロパティ

    //敵のレベル
    public int Level
    {
        get { return this.level; }
        private set { this.level = value; }
    }

    //--------------------------------------------------------------------------
    //コンストラクタ
    public EnemyBase()
    {
        //パラメータを生成
        this.param = new CharaParameter
            (   "Enemy",
                20,
                5,
                5,
                "1",
                "1",
                "1"
            );
        this.Level = 1;
        this.param.CType = CharaParameter.CharaType.Enemy;
    }
    //引数（生成元, ファイル名）
    public EnemyBase(GameObject go,string path)
    {
        //データをロード
        this.eData = EnemyDataLoad(path);

        //パラメータを生成
        this.param = new CharaParameter
            (   this.eData.name,
                this.eData.hp,
                this.eData.power,
                this.eData.dodgeRate,
                this.eData.attackName,
                this.eData.recoverName,
                this.eData.enhanceName
            );
        this.Level = this.eData.level;
        this.param.CType = CharaParameter.CharaType.Enemy;

        ComponentSetting(go);
        AnimTypeChange(eData.animType);
    }

    //--------------------------------------------------------------------------
    //エネミーデータをリソースからロード
    //引数（ファイル名）
    EnemyData EnemyDataLoad(string path)
    {
        EnemyData data = new EnemyData();

        try
        {
            //ファイルへのパス
            string filePath = "Text/EnemyData/Stage_" + BattleDirector.stageNum + "/" + path;

            TextAsset textData = Resources.Load<TextAsset>(filePath);

            StringReader reader = null;

            try
            {
                reader = new StringReader(textData.text);

                //一行ずつデータを読み込み格納
                data.name           = reader.ReadLine();
                data.hp             = int.Parse(reader.ReadLine());
                data.power          = int.Parse(reader.ReadLine());
                data.dodgeRate      = int.Parse(reader.ReadLine());
                data.attackName     = reader.ReadLine();
                data.recoverName    = reader.ReadLine();
                data.enhanceName    = reader.ReadLine();
                data.level          = int.Parse(reader.ReadLine());
                data.animType       = int.Parse(reader.ReadLine());
                

                //成功
                Debug.Log("テキスト読み込み成功:" + filePath);
            }
            //エラー時
            catch(System.Exception e_)
            {
                Debug.LogWarning(e_.Message);
                Debug.LogWarning("文字列の読み込みに失敗:" + filePath);

            }
            //必ず処理
            finally
            {
                reader.Close();
            }
        }
        //エラー時
        catch(System.Exception e_)
        {
            Debug.LogWarning(e_.Message);
            Debug.LogWarning("テキストがありません：" + path);
        }
        return data;
    }
    //--------------------------------------------------------------------------


}
