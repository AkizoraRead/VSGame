﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//SE操作クラス
//--------------------------------------------------------------------------
public class SEController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    SoundReader soundRederClass;    //音源読み込みクラス
    AudioSource audioS;             //

    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //コンポーネント接続
        this.soundRederClass = GameObject.Find("SoundDirector").GetComponent<SoundReader>();
        this.audioS = GetComponent<AudioSource>();

        //初期設定
        this.audioS.loop = false;
        this.audioS.playOnAwake = false;
        SE_VolumeSet(1.0f);
    }

    // Update is called once per frame
    void Update()
    {

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //SEの開始
    //引数（SEの名前）
    public void SE_Play(string name)
    {
        //クリップ読み込み
        AudioClip audioClip = this.soundRederClass.Sound(name);
        //クリップがなければ処理しない
        if (audioClip == null) { return; }

        this.audioS.PlayOneShot(audioClip);     
    }
    //--------------------------------------------------------------------------
    //SEの音量調整
    //引数（音量 0.0f ～ 1.0f）
    public void SE_VolumeSet(float value)
    {
        this.audioS.volume = value;
    }
    //--------------------------------------------------------------------------
    //SEのスピード(ピッチ)
    //引数（スピード倍率）
    public void SE_Pitch(float value)
    {
        this.audioS.pitch = value;
    }
    //--------------------------------------------------------------------------
    //SEの終了時間を返す
    //引数（SEの名前）
    public float SE_Time(string name)
    {
        //クリップ読み込み
        AudioClip audioClip = this.soundRederClass.Sound(name);
        //クリップがなければ処理しない
        if (audioClip == null) { return 0.0f; }

        float seTime = audioClip.length / Time.deltaTime;
        return seTime;
    }
    //--------------------------------------------------------------------------
    //SEをループさせる
    //引数（SEの名前）
    public void SE_Loop(string name)
    {
        //クリップ読み込み
        AudioClip audioClip = this.soundRederClass.Sound(name);
        //クリップがなければ処理しない
        if (audioClip == null) { return; }

        this.audioS.Stop();
        this.audioS.loop = true;
        this.audioS.clip = audioClip;
        this.audioS.Play();
    }
    //--------------------------------------------------------------------------
    //SEを止める
    public void SE_Stop()
    {
        this.audioS.Stop();
    }
    //--------------------------------------------------------------------------
}
