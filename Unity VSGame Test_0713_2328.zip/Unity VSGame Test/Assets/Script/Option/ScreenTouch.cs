﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//画面タッチ(クリック)の反応
//--------------------------------------------------------------------------
public class ScreenTouch : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド
    public bool         isTouch;    //タッチの有無
    public Vector2      touchPos;   //タッチした座標(スクリーン座標)
    public TouchPhase   touchState; //タッチの状態(   押した瞬間,  離した瞬間,  押している間)

    EffectGenerator effectClass;    //エフェクト生成クラス
    Canvas uiCanvas;

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.effectClass    = GameObject.Find("Generator").GetComponent<EffectGenerator>();
        this.uiCanvas       = GameObject.Find("TouchCanvas").GetComponent<Canvas>();
    }

    // Update is called once per frame
    void Update()
    {
        Touch_Update();
        //タッチしているとき
        if(this.isTouch)
        {
            //押した瞬間
            if(touchState == TouchPhase.Began)
            {
                //エフェクト生成
                GameObject go = this.effectClass.EffectGenerate("TouchEffect");
                go.transform.SetParent(this.uiCanvas.gameObject.transform);

                go.transform.position = touchPos;

            }
        }
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //タッチ関連の更新
    void Touch_Update()
    {
        this.isTouch = false;

        //エディター
        if(Application.isEditor)
        {
            //押した瞬間
            if(Input.GetMouseButtonDown(0))
            {
                this.isTouch = true;
                this.touchState = TouchPhase.Began;
                Debug.Log("押した瞬間");
            }
            //離した瞬間
            else if(Input.GetMouseButtonUp(0))
            {
                this.isTouch = true;
                this.touchState = TouchPhase.Ended;
                Debug.Log("離した瞬間");
            }
            //押している間
            else if(Input.GetMouseButton(0))
            {
                this.isTouch    = true;
                this.touchState = TouchPhase.Moved;
                Debug.Log("押している間");
            }

            //座標取得
            if (this.isTouch) { this.touchPos = Input.mousePosition; }
        }
        //端末
        else
        {
            //タッチ反応がひとつでもある時
            if(Input.touchCount > 0)
            {
                Touch touch     = Input.GetTouch(0);
                this.isTouch    = true;
                this.touchState = touch.phase;
                this.touchPos   = touch.position;
            }
        }

    }
    //--------------------------------------------------------------------------
}
