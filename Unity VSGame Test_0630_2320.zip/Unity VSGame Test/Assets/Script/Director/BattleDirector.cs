﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ターンの状況(誰のターンか)
    public enum BattleTurn
    {
        None,       //どちらでもない
        Player,     //プレイヤー
        Enemy,      //エネミー
    }
    //ターンの状態
	public enum TurnState
	{
        Start,  //ターン開始
        InGame, //ゲーム実行中
        End,    //ターン終了
    }

    //--------------------------------------------------------------------------


    public static BattleTurn battleTurn;    //ターンの状況
    public static TurnState turnState;      //ターンの状態
    public static int stageNum;             //ステージ番号
    public static bool isGaming;            //ゲーム中か
    public static bool isMenu;              //メニューを開いているか

    bool isStart;   //一度のみの処理に使う




    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンで一番最初に処理する
    void Awake()
    {
        //初期処理が終わるまでターンは動かさない
        BattleDirector.battleTurn = BattleTurn.None;
        BattleDirector.turnState = TurnState.Start;

        //ステージ設定
        switch (BattleDirector.stageNum)
        {
            case 0: break;  //チュートリアル
            case 1: break;
            case 2: break;
            case 3: break;
            default:break;  //エラー処理
        }

        BattleDirector.battleTurn = BattleTurn.Player;

    }

    // Update is called once per frame
    void Update()
    {
		if (Input.GetKeyDown(KeyCode.Alpha1)) 
        {
            BattleEnd(); 
        }
    }

    //--------------------------------------------------------------------------
    //バトルシーン最初に行うべき処理

    //ターン開始処理
    void BattleStart()
    {
        //操作系統オン

        //ゲームモードへ
        turnState = TurnState.InGame;
    }

    //ターン終了処理
    void BattleEnd()
    {
        //次のターンへ
        if (battleTurn == BattleTurn.Player)
        {
            //敵がいなければクリア
            GameObject enemy = GameObject.FindGameObjectWithTag("Enemy");
            if (enemy == null)
            {
                //ゲームクリア

                Debug.Log("ゲームクリア");

                return;
            }

            //ステータス効果時間のチェック
            PlayerBattle playerData = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBattle>();
            playerData.playerBase.cDataClass.recoverCommand.CheckRecoverTurn(ref playerData.param); //回復チェック
            playerData.playerBase.cDataClass.enhanceCommand.CheckEnhanceTurn(ref playerData.param); //強化チェック
            
            //ターン変更
            battleTurn = BattleTurn.Enemy;
        }
        else if (battleTurn == BattleTurn.Enemy)
        {
            GameObject[] enemys = GameObject.FindGameObjectsWithTag("Enemy");
            //ステータス効果時間のチェック
            foreach (GameObject go in enemys)
            {
                EnemyBattle enemyData = go.GetComponent<EnemyBattle>();
                enemyData.enemyBase.cDataClass.recoverCommand.CheckRecoverTurn(ref enemyData.param);    //回復チェック
                enemyData.enemyBase.cDataClass.enhanceCommand.CheckEnhanceTurn(ref enemyData.param);    //強化チェック
            }

            //ターン変更
            battleTurn = BattleTurn.Player;
        }

        //ターンスタート
        turnState = TurnState.Start;
    }

    //ステージデータをロード(エネミーについてやラウンド数など)

    //BGMをロード

    //背景をロード

    //チュートリアル
}
