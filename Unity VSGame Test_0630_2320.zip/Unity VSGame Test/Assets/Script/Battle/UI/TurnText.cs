﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TurnText : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    BattleDirector.BattleTurn preBattleTurn;    //実行中のバトルターン
    bool isMoving;  //実行中か
    bool isInOut;   //画面イン・アウト
    float deltaTime;    //経過時間
    [SerializeField] float easingInTime = 0.0f;     //画面インに使う時間
    [SerializeField] float easingOutTime = 0.0f;    //画面アウトに使う時間

    Text turnText;  //メッセージを表示するテキスト

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //初期設定
        this.preBattleTurn = BattleDirector.BattleTurn.None;
        this.deltaTime = 0.0f;

        this.isMoving = false;
        this.isInOut = true;

        this.turnText = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
		if (this.isMoving == false &&                                       //未実行中か
            BattleDirector.turnState == BattleDirector.TurnState.Start &&   //ターン開始時
            this.preBattleTurn != BattleDirector.battleTurn)                //前回実行した時と別の種類のターンか
		{
			this.isMoving = true;
            this.preBattleTurn = BattleDirector.battleTurn;
            TextChange(this.preBattleTurn.ToString());
		}

        //実行中のとき
        if (this.isMoving)
        {
            //プレイヤーのターンの場合
            if (this.preBattleTurn == BattleDirector.BattleTurn.Player)
            {
                //画面イン
                if (this.isInOut)
                {
                    ScreenIn(Screen.width / 2.0f);
                }
                //画面アウト
                else
                {
                    ScreecOut(Screen.width + 500.0f);
                }
            }
            //エネミーのターンの場合
            else if(this.preBattleTurn == BattleDirector.BattleTurn.Enemy)
            {
                //画面イン
                if (this.isInOut)
                {
                    ScreenIn(Screen.width / 2.0f);
                }
                //画面アウト
                else
                {
                    ScreecOut(-500.0f);
                }
            }
            //例外
            else
			{
                isMoving = false;   //実行終了
			}
        }
    }
    //--------------------------------------------------------------------------
    //画面イン
    //引数（目的座標値x）
    void ScreenIn(float endPosX)
	{
        float posX = Easing2D.ExpIn(this.deltaTime, this.easingInTime, transform.position.x, endPosX);

        transform.position = new Vector2(posX,
                                         transform.position.y);
        if (this.deltaTime <= this.easingInTime)
        {
            this.deltaTime += Time.deltaTime;
        }
        else
        {
            this.deltaTime = 0.0f;
            this.isInOut = false;
        }
    }
    //--------------------------------------------------------------------------
    //画面アウト
    //引数（目的座標値x）
    void ScreecOut(float endPosX)
	{
        float posX = Easing2D.ExpIn(this.deltaTime, this.easingOutTime, transform.position.x, endPosX);

        transform.position = new Vector2(posX,
                                         transform.position.y);
        if (this.deltaTime <= this.easingOutTime)
        {
            this.deltaTime += Time.deltaTime;
        }
        else
        {
            this.deltaTime = 0.0f;
            this.isInOut = true;
            this.isMoving = false;  //実行終了
        }
    }
    //--------------------------------------------------------------------------
    //メッセージ変更
    //引数（表示するキーワード）
    void TextChange(string msg)
    {
        this.turnText.text = msg;
    }
    //--------------------------------------------------------------------------
}
