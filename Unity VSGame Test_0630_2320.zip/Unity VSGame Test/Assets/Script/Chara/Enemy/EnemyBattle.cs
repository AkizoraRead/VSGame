﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBattle : MonoBehaviour , CharaCommand
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンでのエネミーの処理
    //--------------------------------------------------------------------------
    //フィールド

    public EnemyBase enemyBase;   //エネミーの変数などのデータ

    //値が変化する可能性があるパラメータ
    public CharaParameter param;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.enemyBase = new EnemyBase(gameObject);

        this.param = enemyBase.param;
        this.param.target = GameObject.FindGameObjectWithTag("Player");
        this.param.Hp = this.param.MaxHp;
    }

    void Update()
    {

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //登録された攻撃コマンドを実行する
        this.enemyBase.cDataClass.attackCommand.cData[this.param.AttackCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.enemyBase.cDataClass.recoverCommand.cData[this.param.RecoverCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.enemyBase.cDataClass.enhanceCommand.cData[this.param.EnhanceCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        this.param.Hp -= param_.Power;

        //体力が残っているかチェック
        if (this.param.CheckNoHasHP())
        {
            //破壊処理
            Debug.Log(gameObject.name + "消滅");
        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
