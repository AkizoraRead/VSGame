﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;

//攻撃コマンドを格納
public class CharaAttackCommand : CharaCommandBase
{
    //攻撃コマンド
    //--------------------------------------------------------------------------
    //受け取った変数によって返すコマンドを変える
    public CharaAttackCommand()
    {
        string[] str = { "1", "2" };

        this.cdName = str;

        foreach (string name_ in this.cdName)
        {
            this.cData.Add(name_, CommandDataSet(name_, CommandType.Attack));
        }
    }
    //--------------------------------------------------------------------------
    //コマンド処理を設定
    //引数(コマンド名)
    protected override Command CommandSet(string name_)
    {
        Command command_ = null;

        switch (name_)
        {
            case "1": command_ = AttackCommand_1; break;
            case "2": command_ = AttackCommand_2; break;
            default:
                Debug.LogWarning(name_ + "というコマンドは存在しない\n自動的に1を設定します。");
                command_ = AttackCommand_1;
                break;
        }

        return command_;
    }

    //--------------------------------------------------------------------------
    //攻撃対象のパラメータの取得する
    //引数（攻撃対象のオブジェクト）
    CharaParameter GetTargetParameter(GameObject target)
    {
        CharaParameter param = new CharaParameter();
        if (target.tag == "Player")
        {
            param = target.GetComponent<PlayerBattle>().param;
        }
        else if (target.tag == "Enemy")
        {
            param = target.GetComponent<EnemyBattle>().param;
        }
        //エラー処理
        else
        {
            Debug.LogError(target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
        }
        return param;
    }
    //--------------------------------------------------------------------------
    //攻撃対象へのダメージ処理
    //引数（攻撃元のパラメータ情報）
    void TargetDamame(CharaParameter me)
    {

        if (me.target.tag == "Player")
        {
            me.target.GetComponent<PlayerBattle>().Damage(me);
        }
        else if (me.target.tag == "Enemy")
        {
            me.target.GetComponent<EnemyBattle>().Damage(me);
        }
        //エラー処理
        else
        {
            Debug.LogError(me.target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //攻撃コマンドはここに追加していく
    void AttackCommand_1(ref CharaParameter param_)
    {
        //攻撃対象のパラメータの取得する
        CharaParameter enemy = GetTargetParameter(param_.target);

        //HitCheck
        int hit = Random.Range(0, 100);
        if(hit >= enemy.DodgeRate) 
        {
            //成功
            //ダメージ処理
            TargetDamame(param_);

        }
        else
        {
            //失敗
            Debug.Log("攻撃ミス！");
        }


        Debug.Log("AttackCommand_1 : 実行");
    }

    void AttackCommand_2(ref CharaParameter param_)
    {
        //攻撃対象のパラメータの取得する
        CharaParameter enemy = GetTargetParameter(param_.target);


        Debug.Log("AttackCommand_2 : 実行");
    }

}
