﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Easing2D : MonoBehaviour
{
    //イージング関数

    //
    public static float ExpIn(float t, float totaltime, float min, float max)
    {
        max -= min;
        return t == 0.0 ? min : max * Mathf.Pow(2, 10 * (t / totaltime - 1)) + min;
    }

    public static float ExpOut(float t, float totaltime, float min, float max)
    {
        max -= min;
        return t == totaltime ? max + min : max * (-Mathf.Pow(2, -10 * t / totaltime) + 1) + min;
    }
    public static float ExpInOut(float t, float totaltime, float min, float max)
    {
        if (t == 0.0f) return min;
        if (t == totaltime) return max;
        max -= min;
        t /= totaltime / 2;

        if (t < 1) return max / 2 * Mathf.Pow(2, 10 * (t - 1)) + min;

        t = t - 1;
        return max / 2 * (-Mathf.Pow(2, -10 * t) + 2) + min;

    }
}
