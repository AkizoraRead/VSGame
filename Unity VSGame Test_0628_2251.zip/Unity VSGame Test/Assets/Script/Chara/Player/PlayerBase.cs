﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBase : CharaBase
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤー固有のパラメータや関数
    //--------------------------------------------------------------------------
    //コンストラクタ
    public PlayerBase(GameObject go)
    {
        //初期化
        CharaLoad("PlayerData", go);        //プレイヤーのデータをロード、変数を反映

        //プレイヤー固有の変更
        this.CType = CharaType.Player;
        ColorChange(this.color);    //色替え

    }

    //--------------------------------------------------------------------------
    //キャラの色変更
    public void ColorChange(Color color_)
    {
        this.color = color_;
        this.sprite.color = color;
    }

    //--------------------------------------------------------------------------

}
