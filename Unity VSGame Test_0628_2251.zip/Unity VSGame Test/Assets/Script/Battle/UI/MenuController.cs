﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //メニュー管理
    //--------------------------------------------------------------------------
    //フィールド

    GameObject menuObj; //メニューに使うObject


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //接続
        this.menuObj = GameObject.Find("MenuCanvas");
        Menu(false);
    }

    // Update is called once per frame
    void Update()
    {


    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //メニューで行えるボタンの処理
    //--------------------------------------------------------------------------
    //メニューモードのON:OFF
    public void Menu(bool isFlag)
    {
        //ゲーム中のみ処理
        //if (!BattleDirector.isGaming) { return; }

        BattleDirector.isMenu = isFlag;
        this.menuObj.SetActive(isFlag);

        Debug.Log("Menu:" + isFlag);
    }

    //ゲーム終了（アプリケーション終了）
    public void GameQuit()
    {
        //保存するものはここで処理しておく

        Debug.Log("ゲーム終了");
        Application.Quit();
    }
}
