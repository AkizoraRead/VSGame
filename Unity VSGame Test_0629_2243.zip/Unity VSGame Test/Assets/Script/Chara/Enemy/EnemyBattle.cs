﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBattle : MonoBehaviour , CharaCommand
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンでのエネミーの処理
    //--------------------------------------------------------------------------
    //フィールド

    public EnemyBase enemyBase;   //エネミーの変数などのデータ

    //値が変化する可能性があるパラメータ
    public CharaParameter param;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.enemyBase = new EnemyBase(gameObject);

        this.param = new CharaParameter(15,10,10);
        this.param.target = GameObject.FindGameObjectWithTag("Player");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.S)) { Debug.Log(this.param.CharaParameterLog()); }

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //登録された攻撃コマンドを実行する
        this.enemyBase.cDataClass.attackCommand.cData[this.enemyBase.AttackCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.enemyBase.cDataClass.recoverCommand.cData[this.enemyBase.RecoverCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.enemyBase.cDataClass.enhanceCommand.cData[this.enemyBase.EnhanceCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        this.param.Hp -= param_.Power;

        //体力が残っているかチェック
        if (this.param.CheckNoHasHP())
        {
            //破壊処理

        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
