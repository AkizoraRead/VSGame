﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //音源の操作を統括するクラス
    //--------------------------------------------------------------------------
    //フィールド

    BGMController   bgmClass;   //BGMクラス
    SEController    seClass;    //SEクラス

    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.bgmClass = transform.Find("BGMController").GetComponent<BGMController>();
        this.seClass = transform.Find("SEController").GetComponent<SEController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
