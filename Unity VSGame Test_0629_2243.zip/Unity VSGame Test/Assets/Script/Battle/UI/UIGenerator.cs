﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIGenerator : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //UIの生成を行うクラス
    //--------------------------------------------------------------------------
    //フィールド

    [SerializeField] GameObject charaHPGaugeObj = null;  //キャラのHPゲージオブジェクト

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラHPゲージを生成して返す
    //引数（生成元,UI表示のキャンバス）
    public GameObject CreateCharaHPGauge(GameObject obj,Canvas canvas)
    {
        GameObject go = Instantiate(this.charaHPGaugeObj) as GameObject;
        go.GetComponent<HPGauge>().obj = obj;
        go.transform.SetParent(canvas.transform);

        //座標値を合わせる
        float posX = 0.0f;
        if(obj.tag == "Player") { posX = Screen.width / 5.0f; }
        else if(obj.tag == "Enemy") { posX = Screen.width / 5.0f * 4.0f; }

        go.transform.position = new Vector3(posX, Screen.height / 5.0f * 4.0f, 0.0f);

        //大きさをキャンパスに合わせる
        go.transform.localScale = go.transform.lossyScale;


        return go;
    }
}
