﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class TextLoad
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //テキストアセットの読み込みをするクラス
    //--------------------------------------------------------------------------


    string[] textMsg;   //ロードした文字列
    int lineValue;      //読み込んだテキストの行数

    //--------------------------------------------------------------------------
    //初期化
    public TextLoad()
    {
        this.textMsg = null;
        this.lineValue = 0;

    }
    //--------------------------------------------------------------------------
    //テキストを読み込み返す
    public string[] GetText(string path)
    {
        bool isflag =  LoadText(path);

       

        return this.textMsg;
    }
    //--------------------------------------------------------------------------
    public string[] GetText_CommandLog(string path,CharaCommandBase.CommandType type)
    {
        string commandPath = "";
        switch (type)
        {
            //case CharaCommandBase.CommandType.Attack: commandPath = new string;
        }


        bool isflag = LoadText(path);



        return this.textMsg;
    }

    //--------------------------------------------------------------------------
    //リソースからテキストをロード
    bool LoadText(string path)
    {
        try
        {
            //リソースからファイル(.txt,.csv)をロード
            TextAsset textAsset = Resources.Load("Text/" + path) as TextAsset;

            //文字列を読み取る型
            StringReader reader = new StringReader(textAsset.text);

            try
            {
                //ロードしたテキストを保存しておく変数
                List<string> textList = new List<string>();

                //一行ずつ読み込み、配列に追加していく
                //読み込む文字列がなくなるまでループ
                for (this.lineValue = 0; reader.Peek() != -1; lineValue++)
                {
                    string line = reader.ReadLine();    //一行読み込み
                    textList.Add(line);                     //リストに追加
                }
                
                //Listをstring[]に変換
                this.textMsg = new string[this.lineValue];  //配列の大きさを行数によって決める
                for(int i = 0;i < this.lineValue;i++)
                {
                    this.textMsg[i] = textList[i];
                }


            }
            //エラーが出た場合
            catch(System.Exception e_)
            {
                Debug.LogWarning(e_.Message);
                this.textMsg = new string[2]; 
                this.textMsg[0] = "ロード失敗：TextAsset.text";
                this.textMsg[1] = "パス：" + path;

                return false;
            }
            //必ず最後に行う処理
            finally
            {
                //リード終了
                reader.Close();
            }

            //正常に処理を終了
            return true;
        }
        //エラーが出た場合
        catch(System.Exception e_)
        {
            Debug.LogWarning(e_.Message);
            this.textMsg = new string[2];
            this.textMsg[0] = "ロード失敗：TextAsset";
            this.textMsg[1] = "パス：" + path;
            
            return false;
        }
    }
}
