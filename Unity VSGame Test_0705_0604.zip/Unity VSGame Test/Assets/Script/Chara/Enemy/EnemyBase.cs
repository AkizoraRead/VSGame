﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : CharaBase
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤー固有のパラメータや関数
    //--------------------------------------------------------------------------
    //コンストラクタ
    public EnemyBase(GameObject go):base("")
    {
        //初期化
        this.param.CType = CharaParameter.CharaType.Enemy;
        ComponentSetting(go);
    }

    //--------------------------------------------------------------------------

}
