﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyBattle : MonoBehaviour , CharaCommand
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンでのエネミーの処理
    //--------------------------------------------------------------------------
    //フィールド

    BattleDirector director;        //シーンでの統括クラス
    CharaUIManager uiClass;         //キャラごとのUI操作クラス
    public EnemyBase enemyBase;     //エネミーの変数などのデータ

    //値が変化する可能性があるパラメータ
    public CharaParameter param;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.director = GameObject.Find("BattleDirector").GetComponent<BattleDirector>();
        this.uiClass = GetComponent<CharaUIManager>();
        this.enemyBase = new EnemyBase(gameObject);

        this.param = enemyBase.param;
        this.param.target = GameObject.FindGameObjectWithTag("Player");
        this.param.Hp = this.param.MaxHp;
    }

    void Update()
    {
        //敵の行動ルーチン
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //登録された攻撃コマンドを実行する
        this.enemyBase.cDataClass.attackCommand.cData[this.param.AttackCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.enemyBase.cDataClass.recoverCommand.cData[this.param.RecoverCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.enemyBase.cDataClass.enhanceCommand.cData[this.param.EnhanceCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        //HP減少
        this.param.Hp -= param_.Power;

        //ダメージ表示
        Text text = this.uiClass.CreateText(param_.Power.ToString(), gameObject);
        text.color = new Color(1.0f, 0.0f, 0.0f);   //文字の色を赤に

        //体力が残っているかチェック
        if (this.param.CheckNoHasHP())
        {
            //消滅処理
            Invoke("Destroy", 1.0f);

            //クリア判定
            this.director.Invoke("CheckGameClear", 1.1f);

            Debug.Log(gameObject.name + "消滅");
        }
    }
    //--------------------------------------------------------------------------
    //自分への回復処理
    //引数（回復量）
    public void Recover(int value)
    {
        //回復後の体力
        int newHP = this.param.Hp + value;

        //回復後のHPが最大体力を超えていないかチェック
        if (this.param.CheckMaxHP(newHP)) { this.param.Hp = this.param.MaxHp; }
        else { this.param.Hp = newHP; }

        //回復値を表示
        Text text = this.uiClass.CreateText(value.ToString(), gameObject);
        text.color = new Color(0.0f, 1.0f, 0.0f);   //文字の色を緑に
    }
    //--------------------------------------------------------------------------
    //コマンドミス
    public void Miss()
    {
        Text text = this.uiClass.CreateText("ミス", gameObject);
        text.color = new Color(0.0f, 0.0f, 0.0f);   //文字の色を黒に
    }
    //--------------------------------------------------------------------------
    //破壊処理
    void Destroy()
    {
        Destroy(gameObject);
    }
    //--------------------------------------------------------------------------
}
