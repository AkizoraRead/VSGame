﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using UnityEngine;

public class CharaParameter
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラクターに使用するパラメータ
    //--------------------------------------------------------------------------
    //キャラクターの種類
    public enum CharaType
    {
        None = 0,
        Player = 1,
        Enemy = 2,
    }
    //--------------------------------------------------------------------------
    //フィールド

    //パラメータ バトルで必要な情報のみ
    [SerializeField] string name;        //キャラクターネーム
    [SerializeField] int maxHp;          //体力上限
    [SerializeField] int power;          //攻撃力
    [SerializeField] int dodgeRate;      //回避率
    [SerializeField] CharaType cType;    //キャラの種類

    [SerializeField] string attackCName;    //初期設定用　コマンドネーム
    [SerializeField] string recoverCName;   //初期設定用　コマンドネーム
    [SerializeField] string enhanceCName;   //初期設定用　コマンドネーム
    public Color color;              //色

    int hp;             //体力(変化する)

    public GameObject myself;   //自分
    public GameObject target;   //攻撃対象

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プロパティ

    //名前
    public string Name
    {
        get { return this.name; }
        set { this.name = value; }
    }
    //体力上限
    public int MaxHp
    {
        get { return maxHp; }
        set { this.maxHp = value; }
    }
    //体力    
    public int Hp
    {
        get { return hp; }
        set { this.hp = value; }
    }
    //攻撃力
    public int Power
    {
        get { return this.power; }
        set { this.power = value; }
    }
    //回避率
    public int DodgeRate
    {
        get { return this.dodgeRate; }
        set { this.dodgeRate = value; }
    }

    //キャラの種類
    public CharaType CType
    {
        get { return this.cType; }
        set { this.cType = value; }
    }
    //コマンド名
    //Attack
    public string AttackCName
    {
        get { return this.attackCName; }
        set { this.attackCName = value; }
    }
    //Recover
    public string RecoverCName
    {
        get { return this.recoverCName; }
        set { this.recoverCName = value; }
    }
    //Enhance
    public string EnhanceCName
    {
        get { return this.enhanceCName; }
        set { this.enhanceCName = value; }
    }


    //パラメータ構造体の初期化
    public CharaParameter()
    {
        this.name = "NoName";
        this.MaxHp = 10;
        this.Hp = 0;
        this.Power = 10;
        this.DodgeRate = 10;
        this.AttackCName = "1";
        this.RecoverCName = "1";
        this.EnhanceCName = "1";
        this.myself = null;
        this.target = null;
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public CharaParameter(string name_, int hp_, int power_, int dodgeRate_ ,string attackCName_, string recoverCName_,string enhanceCName_)
    {
        this.name = name_;
        this.MaxHp = hp_;
        this.Hp = hp_;
        this.Power = power_;
        this.DodgeRate = dodgeRate_;
        this.AttackCName = attackCName_;
        this.RecoverCName = recoverCName_;
        this.EnhanceCName = enhanceCName_;
        this.myself = null;
        this.target = null;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラパラメータログ    stringで返す
    //--------------------------------------------------------------------------
    //全て
    public string CharaDataAllLog()
    {
        string log = "";

        //パラメータを追加したらこの下に追記する
        log += name + "\n";
        log += GetCTypeLog();                 //キャラタイプ
        log += GetHPLog();                    //HP
        log += GetPowerLog();                 //Power
        log += GetDodgeRateLog();             //DodgeRat
        log += GetColorLog();                 //色
        log += GetAttackCommandNameLog();     //攻撃コマンドネーム
        log += GetRecoverCommandNameLog();    //回復コマンドネーム
        log += GetEnhanceCommandNameLog();    //強化コマンドネーム

        return log;
    }
    //--------------------------------------------------------------------------
    //HP
    public string GetHPLog()
    {
        string log = "HP:" + this.MaxHp.ToString() + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //Power
    public string GetPowerLog()
    {
        string log = "Power:" + this.Power.ToString() + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //DodgeRate
    public string GetDodgeRateLog()
    {
        string log = "DodgeRate:" + this.DodgeRate.ToString() + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //CharaType
    public string GetCTypeLog()
    {
        string log = "CharaType:" + this.cType.ToString() + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //Color
    public string GetColorLog()
    {
        string log = "Color:" + this.color.ToString() + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //AttackCommandName
    public string GetAttackCommandNameLog()
    {
        string log = "Attack:" + this.attackCName + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //RecoverCommandName
    public string GetRecoverCommandNameLog()
    {
        string log = "Recover:" + this.recoverCName + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //EnhanceCommandName
    public string GetEnhanceCommandNameLog()
    {
        string log = "Enhance:" + this.enhanceCName + "\n";
        return log;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //セーブ
    //--------------------------------------------------------------------------
    //Json形式にpublic,[SerializeField]の変数を変換
    public string CharaParameter_ToJson()
    {
        return JsonUtility.ToJson(this);
    }
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    //引数(格納するデータ名)
    public void CharaDataSave(string name)
    {
        PlayerPrefs.SetString(name, CharaParameter_ToJson());
        PlayerPrefs.Save();
        Debug.Log("保存完了");
    }

    //--------------------------------------------------------------------------
    //ロード
    public CharaParameter CharaParameterLoad(string name)
    {

        //nameという名のデータが保存されているか
        if (PlayerPrefs.HasKey(name))
        {
            //上書き
            var data = PlayerPrefs.GetString(name);
            JsonUtility.FromJsonOverwrite(data, this);
            Debug.Log("ロード成功:" + name);
            return this;
        }
        else
        {
            Debug.LogWarning(name + "という名のデータは保存されていませんでした。");
            return new CharaParameter();
        }
        //セッティング(読み込みだけでは変わらない部分を初期化する)
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //結果を返す
    //--------------------------------------------------------------------------
    //体力が0以下か判定を返す
    public bool CheckNoHasHP()
    {
        if (this.Hp <= 0) { this.Hp = 0; return true; }
        else { return false; }
    }
    //--------------------------------------------------------------------------
    //値が最大体力を超えたかどうか
    public bool CheckMaxHP(int value)
    {
        if(value > this.MaxHp) { return true; }
        else { return false; }
    }
    //--------------------------------------------------------------------------
}
