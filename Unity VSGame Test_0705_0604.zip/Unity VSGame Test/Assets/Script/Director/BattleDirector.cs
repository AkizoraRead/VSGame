﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンでの統括
    //--------------------------------------------------------------------------
    //ターンの状況(誰のターンか)
    public enum BattleTurn
    {
        None,       //どちらでもない(ゲームエンド)
        Player,     //プレイヤー
        Enemy,      //エネミー
    }
    //ターンの状態
	public enum TurnState
	{
        Start,  //ターン開始
        InGame, //ゲーム実行中
        End,    //ターン終了
    }

    //ゲーム終了の状態
    public enum EndState
    {
        None,       //終了していない
        Clear,      //クリア
        Over,       //ゲームオーバー
    }


    //--------------------------------------------------------------------------
    //フィールド

    public static BattleTurn    battleTurn;     //ターンの状況
    public static TurnState     turnState;      //ターンの状態
    public static EndState      endState;      //ターンの状態
    public static int   turnCnt;                //ターン数
    public static int   stageNum;               //ステージ番号
    public static bool  isGaming;               //ゲーム中か
    public static bool  isMenu;                 //メニューを開いているか
    public static int   score;                  //スコア
    

    public static List<string> battleLog;       //バトルシーンでのログ

    bool isStart;   //始め一回の処理に使う
    float delta;    //経過時間計測
    float interval; //ターン変移の時間




    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンで一番最初に処理する
    void Awake()
    {
        //初期処理が終わるまでターンは動かさない
        BattleDirector.battleTurn = BattleTurn.None;
        BattleDirector.turnState = TurnState.Start;
        BattleDirector.endState = EndState.None;
        BattleDirector.turnCnt = 0;
        BattleDirector.battleLog = new List<string>();
        BattleDirector.score = 0;

        //ステージ設定
        switch (BattleDirector.stageNum)
        {
            case 0: break;  //チュートリアル
            case 1: break;
            case 2: break;
            case 3: break;
            default:break;  //エラー処理
        }

        //プレイヤーのターンからスタート
        BattleDirector.battleTurn = BattleTurn.Player;

        this.isStart = true;
        this.delta = 0.0f;
        this.interval = 1.0f;

        
    }

    // Update is called once per frame
    void Update()
    {
        //ターンの状態ごとに処理
        switch(BattleDirector.turnState)
        {
            case TurnState.Start:   BattleStart();  break;
            case TurnState.InGame:  BattleInGame(); break;
            case TurnState.End:     BattleEnd();    break;
        }
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ターン開始処理
    void BattleStart()
    {
        //初回のみ処理
        if (this.isStart)
        {
            //現在のターンの種類ごとに処理
            if (BattleDirector.battleTurn == BattleTurn.Player) //プレイヤー
            {
                //操作系統オン
                BattleDirector.isGaming = true;
                BattleDirector.turnCnt++;   //ターン増加
                BattleDirector.battleLog.Add("プレイヤーのターン");
            }
            else if (BattleDirector.battleTurn == BattleTurn.Enemy)  //エネミー
            {
                BattleDirector.battleLog.Add("エネミーのターン");

            }
            //例外は処理せず
            else
            {
                return;
            }

            this.isStart = false;
        }


        //ターン状態の変移
        if (this.delta < this.interval)
        {
            this.delta += Time.deltaTime;
        }
        else
        {
            //ゲーム中に変更
            TurnStateChange(TurnState.InGame);
        }

    }

    //--------------------------------------------------------------------------
    //ターンゲーム中の処理
    void BattleInGame()
    {
        //操作オフの時
        if(BattleDirector.isGaming == false)
        {
            //初回のみ処理
            if(this.isStart)
            {
                //ターン状態の変更処理
                Invoke("InGameEnd", 1.5f);
                this.isStart = false;
            }
        }
    }
    //--------------------------------------------------------------------------
    //ターン終了処理
    void BattleEnd()
    {
        //初回のみ処理
        if (this.isStart)
        {
            //操作系統オフ


            //次のターンへ
            //現在のターンの種類ごとに処理
            if (BattleDirector.battleTurn == BattleTurn.Player) //プレイヤー
            {
                //ゲームクリアかチェック
                CheckGameClear();

                //ステータス効果時間のチェック
                PlayerBattle playerData = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBattle>();
                playerData.playerBase.cDataClass.recoverCommand.CheckRecoverTurn(ref playerData.param);     //回復チェック
                playerData.playerBase.cDataClass.enhanceCommand.CheckEnhanceTurn(ref playerData.param);     //強化チェック

                //ターン変更
                BattleDirector.battleTurn = BattleTurn.Enemy;
            }
            else if (BattleDirector.battleTurn == BattleTurn.Enemy) //エネミー
            {
                GameObject[] enemys = GameObject.FindGameObjectsWithTag("Enemy");
                //ステータス効果時間のチェック
                foreach (GameObject go in enemys)
                {
                    EnemyBattle enemyData = go.GetComponent<EnemyBattle>();
                    enemyData.enemyBase.cDataClass.recoverCommand.CheckRecoverTurn(ref enemyData.param);    //回復チェック
                    enemyData.enemyBase.cDataClass.enhanceCommand.CheckEnhanceTurn(ref enemyData.param);    //強化チェック
                }

                //ターン変更
                BattleDirector.battleTurn = BattleTurn.Player;
            }

            this.isStart = false;
        }

        //ターン状態の変移
        if (this.delta < this.interval)
        {
            this.delta += Time.deltaTime;
        }
        else
        {
            //スタート状態に変更
            TurnStateChange(TurnState.Start);
        }
    }

    //--------------------------------------------------------------------------
    //ターンの状態を変更
    public void TurnStateChange(TurnState state)
    {
        if(BattleDirector.endState != BattleDirector.EndState.None) { return; }

        BattleDirector.turnState = state;
        this.isStart = true;
        this.delta = 0.0f;
    }
    //--------------------------------------------------------------------------
    //ゲーム終了処理
    //引数（クリア or ゲームオーバー）
    void GameEnd(EndState state)
    {
        //終了状態の更新
        BattleDirector.endState = state;

        //操作系統オフ
        BattleDirector.isGaming = false;

        TurnStateChange(TurnState.Start);
        BattleDirector.battleTurn = BattleTurn.None;

        //ターンでのスコア加算処理
        switch (state)
        {
            //ゲームクリア処理
            case EndState.Clear:
                Debug.Log("ゲームクリア");

                BattleDirector.score += 1000;   //クリアスコア

                //プレイヤーの残りHPの割合
                CharaParameter param = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerBattle>().param;
                int score_ = (int)((float)param.Hp / (float)param.MaxHp * 100.0f);  //残HP / 上限HP * 100倍
                BattleDirector.score += score_;
                break;
            //ゲームオーバー処理
            case EndState.Over:

                Debug.Log("ゲームオーバー");
                break;
            //エラー処理
            default: 
                Debug.LogError("ゲームが正常に終了しませんでした");
                break;
        }


    }
    //--------------------------------------------------------------------------
    //クリア条件を満たしていればクリア
    public void CheckGameClear()
    {
        //クリア条件
        //敵がいるか
        GameObject enemy = GameObject.FindGameObjectWithTag("Enemy");

        if (enemy != null) { return; }

        GameEnd(EndState.Clear);
    }
    //--------------------------------------------------------------------------
    //ゲームオーバー処理
    public void GameOver()
    {
        CancelInvoke();
        GameEnd(EndState.Over);
    }
    //--------------------------------------------------------------------------
    //ターンゲーム中終了
    public void InGameEnd()
    {
        TurnStateChange(TurnState.End);
    }
    //ステージデータをロード(エネミーについてやラウンド数など)

    //BGMをロード

    //背景をロード

    //チュートリアル
}
