﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIGenerator : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //UIの生成を行うクラス
    //--------------------------------------------------------------------------
    //フィールド

    [SerializeField] GameObject charaHPGaugeObj = null;     //キャラのHPゲージオブジェクト
    [SerializeField] GameObject uiTextObj = null;           //ダメージ表示UIテキスト
    [SerializeField] GameObject statusObj = null;           //ステータス画像表示
    [SerializeField] GameObject nameTextObj = null;         //キャラネーム表示テキスト

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラHPゲージを生成して返す
    //引数（参照先,UI表示のキャンバス）
    public GameObject CreateCharaHPGauge(GameObject obj, Canvas canvas)
    {
        GameObject go = Instantiate(this.charaHPGaugeObj) as GameObject;
        go.GetComponent<HPGauge>().target = obj;
        go.transform.SetParent(canvas.transform);

        //座標値を合わせる
        float posX = 0.0f;
        if (obj.tag == "Player") { posX = Screen.width / 5.0f; }
        else if (obj.tag == "Enemy") { posX = Screen.width / 5.0f * 4.0f; }

        //位置・サイズ調整
        go.transform.position = new Vector3(posX, Screen.height / 5.0f * 4.0f, 0.0f);
        go.transform.localScale = go.transform.lossyScale;


        return go;
    }
    //--------------------------------------------------------------------------
    //ダメージ表示UIを生成する
    //引数（表示するテキスト, 参照先 , UI表示のキャンバス）
    public GameObject CreateText(string msg, GameObject obj, Canvas canvas)
    {
        GameObject go = Instantiate(this.uiTextObj) as GameObject;
        Text text = go.GetComponent<Text>();
        go.transform.SetParent(canvas.transform);

        //位置・サイズ調整
        Vector2 pos = obj.transform.position;
        pos.x += obj.transform.localScale.x / 2.0f;
        pos.y += obj.transform.localScale.y / 2.0f;


        go.GetComponent<RectTransform>().position = RectTransformUtility.WorldToScreenPoint(Camera.main, pos);
        go.transform.localScale = go.transform.lossyScale;

        //テキスト表示
        text.text = msg;

        return go;
    }
    //--------------------------------------------------------------------------
    //ステータス画像表示UIを生成する
    //引数（参照先 , UI表示のキャンバス）
    public GameObject CreateStatusImage(GameObject obj, Canvas canvas)
    {
        GameObject go = Instantiate(this.statusObj) as GameObject;
        go.GetComponent<StatusImage>().target = obj;
        go.transform.SetParent(canvas.transform);

        //座標値を合わせる
        float posX = 0.0f;
        if (obj.tag == "Player") { posX = Screen.width / 5.0f; }
        else if (obj.tag == "Enemy") { posX = Screen.width / 5.0f * 4.0f; }

        //位置・サイズ調整
        go.transform.position = new Vector3(posX, Screen.height / 5.0f * 4.0f - (15.0f * (Screen.height /540.0f)), 0.0f);
        go.transform.localScale = go.transform.lossyScale;

        return go;
    }
    //--------------------------------------------------------------------------
    //キャラネーム表示テキストを生成する
    //引数（参照先 , UI表示のキャンバス）
    public GameObject CreateCharaNameText(GameObject obj, Canvas canvas)
    {
        GameObject go = Instantiate(this.nameTextObj) as GameObject;
        go.GetComponent<CharaNameText>().target = obj;
        go.transform.SetParent(canvas.transform);

        //座標値を合わせる
        float posX = 0.0f;
        if (obj.tag == "Player") { posX = Screen.width / 5.0f; }
        else if (obj.tag == "Enemy") { posX = Screen.width / 5.0f * 4.0f; }

        //位置・サイズ調整
        go.transform.position = new Vector3(posX, Screen.height / 5.0f * 4.0f + (18.0f * (Screen.height / 540.0f)), 0.0f);
        go.transform.localScale = go.transform.lossyScale;

        return go;
    }

}
