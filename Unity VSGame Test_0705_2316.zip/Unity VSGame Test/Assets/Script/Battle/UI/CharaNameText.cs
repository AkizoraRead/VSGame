﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharaNameText : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //キャラクターの名前を表示する
    //--------------------------------------------------------------------------
    //フィールド

    public GameObject   target;     //参照先
    CharaParameter      param;      //ターゲットのパラメータ
    Text                nameText;   //名前を表示するテキスト


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.param      = GetParam();
        this.nameText   = GetComponent<Text>();

        //テキスト表示
        this.nameText.text = param.Name;
    }

    // Update is called once per frame
    void Update()
    {
        //参照先がいなくなれば消滅
        if(this.target == null)
        {
            Destroy(gameObject);
        }
    }
    //--------------------------------------------------------------------------
    //パラメータの取得
    CharaParameter GetParam()
    {
        //パラメータの設定
        if (this.target.tag == "Player")
        {
            return this.target.GetComponent<PlayerBattle>().param;
        }
        else if (this.target.tag == "Enemy")
        {
            return this.target.GetComponent<EnemyBattle>().param;
        }
        //エラー処理
        else
        {
            Debug.LogError(target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
            return null;
        }
    }
    //--------------------------------------------------------------------------
}
