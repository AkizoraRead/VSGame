﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerBattle : MonoBehaviour, CharaCommand
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルシーンでのプレイヤーの処理
    //--------------------------------------------------------------------------
    //フィールド

    BattleDirector director;        //シーンでの統括クラス
    CharaUIManager uiClass;         //キャラごとのUI操作クラス
    public PlayerBase playerBase;   //プレイヤーの変数などのデータ

    
    public CharaParameter param;    //値が変化する可能性があるパラメータ
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.director = GameObject.Find("BattleDirector").GetComponent<BattleDirector>();
        this.uiClass = GetComponent<CharaUIManager>();
        this.playerBase = new PlayerBase(gameObject);

        this.param = this.playerBase.param;
        this.param.Hp = this.param.MaxHp;
    }

    void Update()
    {
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //攻撃対象を選択
    public void SetTarget(GameObject enemy)
    {
        this.param.target = enemy;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //ターゲットが指定されていない場合、自動的に検出した敵を選択する
        if(this.param.target == null) { SetTarget(GameObject.FindGameObjectWithTag("Enemy")); }

        //登録された攻撃コマンドを実行する
        this.playerBase.cDataClass.attackCommand.cData[this.param.AttackCName].command(ref this.param);

        //操作オフ
        BattleDirector.isGaming = false;
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.playerBase.cDataClass.recoverCommand.cData[this.param.RecoverCName].command(ref this.param);
        //操作オフ
        BattleDirector.isGaming = false;
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.playerBase.cDataClass.enhanceCommand.cData[this.param.EnhanceCName].command(ref this.param);

        //操作オフ
        BattleDirector.isGaming = false;

    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        this.param.Hp -= param_.Power;

        //ダメージ表示
        Text text = this.uiClass.CreateText(param_.Power.ToString(), gameObject);
        text.color = new Color(1.0f, 0.0f, 0.0f);   //文字の色を赤に

        //体力が残っているかチェック
        if(this.param.CheckNoHasHP())
        {
            //ゲームオーバー処理
            this.director.GameOver();
        }
    }
    //--------------------------------------------------------------------------
    //自分への回復処理
    //引数（回復量）
    public void Recover(int value)
    {
        //回復後の体力
        int newHP = this.param.Hp + value;

        //回復後のHPが最大体力を超えていないかチェック
        if (this.param.CheckMaxHP(newHP)) { this.param.Hp = this.param.MaxHp; }
        else { this.param.Hp = newHP; }

        //回復値を表示
        Text text = this.uiClass.CreateText(value.ToString(), gameObject);
        text.color = new Color(0.0f, 1.0f, 0.0f);   //文字の色を緑に
    }
    //--------------------------------------------------------------------------
    //コマンドミス
    public void Miss()
    {
        Text text = this.uiClass.CreateText("ミス", gameObject);
        text.color = new Color(0.0f, 0.0f, 0.0f);   //文字の色を黒に
    }
    //--------------------------------------------------------------------------
}
