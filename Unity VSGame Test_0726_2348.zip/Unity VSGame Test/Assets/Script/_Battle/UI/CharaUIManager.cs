﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラクターごとのUI操作クラス
//--------------------------------------------------------------------------
public class CharaUIManager : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    Canvas      uiCanvas;       //UIを表示するためのCanvas


    //キャラクターで必要なUIクラス
    BattleUIGenerator uiGenerator;    //HPゲージUIクラス



    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //クラスの設定
        this.uiGenerator = GameObject.Find("Generator").GetComponent<BattleUIGenerator>();

        //オブジェクト設定
        this.uiCanvas = GameObject.Find("CharaUICanvas").GetComponent<Canvas>();

        //HPゲージ生成
        this.uiGenerator.CreateCharaHPGauge(gameObject,this.uiCanvas);

        //ステータス画像表示UI生成
        this.uiGenerator.CreateStatusImage(gameObject, this.uiCanvas);

        //キャラネームテキスト生成
        this.uiGenerator.CreateCharaNameText(gameObject, this.uiCanvas);
    }

    // Update is called once per frame
    void Update()
    {

    }
    //--------------------------------------------------------------------------
    //ダメージ表示UIを生成する
    //引数（表示するテキスト, 生成位置）
    public Text CreateText(string msg, GameObject obj)
    {
        GameObject go = this.uiGenerator.CreateText(msg, obj, this.uiCanvas);
        return go.GetComponent<Text>();
    }
    //--------------------------------------------------------------------------
}
