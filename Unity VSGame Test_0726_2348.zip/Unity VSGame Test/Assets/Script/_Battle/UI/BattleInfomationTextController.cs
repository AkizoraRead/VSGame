﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//バトルシーンでの詳細情報表示
//--------------------------------------------------------------------------
public class BattleInfomationTextController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    int     preTurnCnt;     //前フレームでのターン数
    Text    turnCntText;    //ターン数表示
    Text    stageText;      //ステージ名表示
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.preTurnCnt     = 0;
        this.turnCntText    = transform.Find("TurnCntText").GetComponent<Text>();
        this.stageText      = transform.Find("StageNameText").GetComponent<Text>();

        //ターン数表示
        this.turnCntText.text = "ターン数：" + BattleDirector.turnCnt;
        //ステージ名表示
        string stageName = "";
        if(BattleDirector.stageNum == 0) { stageName = "チュートリアル"; }
        else { stageName = "ステージ" + BattleDirector.stageNum.ToString(); }
        this.stageText.text = stageName;
    }

    void Update()
    {
        //ターン数が変わっていたら更新
        if(this.preTurnCnt != BattleDirector.turnCnt)
        {
            //ターン数表示
            this.turnCntText.text = "ターン数：" + BattleDirector.turnCnt;
            //更新
            this.preTurnCnt = BattleDirector.turnCnt;
        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
