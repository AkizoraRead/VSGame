﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//ゲーム終了時のUI
//--------------------------------------------------------------------------
public class GameEndCanvasController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    float score;    //スコア表示用
    bool isStart;   //一回だけ処理するためのフラグ
    Canvas canvas;  //表示UICanvas
    Text endText;   //終了の状態表示テキスト
    Text scoreText; //スコア表示テキスト

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.score      = 0.0f;
        this.isStart    = true;
        this.canvas     = GetComponent<Canvas>();
        this.endText    = transform.Find("EndStateText").GetComponent<Text>();
        this.scoreText  = transform.Find("ScoreText").GetComponent<Text>();

        this.canvas.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        //ゲーム終了時に処理
        if(BattleDirector.battleTurn == BattleDirector.BattleTurn.None)
        {
            //一度だけ処理
            if (this.isStart)
            {
                this.canvas.enabled = true;

                string str = "";
                switch(BattleDirector.endState)
                {
                    case BattleDirector.EndState.Clear:
                        str = "GAME CLEAR";
                        break;
                    case BattleDirector.EndState.Over:
                        str = "GAME OVER";
                        break;
                }
                this.endText.text = str;

                this.isStart = false;
            }

            //スコア加算表示
            if(BattleDirector.score > this.score)
            {
                this.score += Time.deltaTime * 1000.0f;
            }
            else
            {
                this.score = BattleDirector.score;
            }
            //テキスト反映
            this.scoreText.text = "SCORE：" + this.score.ToString("0000");
        }
    }
    //--------------------------------------------------------------------------
}
