﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//タイトルでの処理を統括するスクリプト
//--------------------------------------------------------------------------
public class TitleDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    OptionDirector  optionClass;    //よく使う機能が入ったクラス
    SoundDirector   soundClass;     //音制御クラス

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.optionClass    = GameObject.Find("OptionDirector").GetComponent<OptionDirector>();
        this.soundClass     = GameObject.Find("SoundDirector").GetComponent<SoundDirector>();

        //BGM再生
        this.soundClass.bgmClass.BGM_SetVolume(0.4f);
        this.soundClass.bgmClass.BGM_Play("BGM_Title");
    }

    void Update()
    {
        if (this.optionClass.touchClass.CheckTouch()) 
        {
            //入力無効のときは処理せず
            if (!OptionDirector.isInput) { return; }

            //SE再生
            this.soundClass.seClass.SE_Play("System01");

            //シーン変更
            this.optionClass.sceneClass.NextScene("SelectScene");

            //入力受付無効化
            OptionDirector.isInput = false;
        }
    }
    //--------------------------------------------------------------------------
}
