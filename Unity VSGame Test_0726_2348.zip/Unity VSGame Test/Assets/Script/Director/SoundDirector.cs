﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//音源の操作を統括するクラス
//--------------------------------------------------------------------------
public class SoundDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    public BGMController    bgmClass;   //BGMクラス
    public SEController     seClass;    //SEクラス

    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.bgmClass   = transform.Find("BGMController").GetComponent<BGMController>();
        this.seClass    = transform.Find("SEController").GetComponent<SEController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
}
