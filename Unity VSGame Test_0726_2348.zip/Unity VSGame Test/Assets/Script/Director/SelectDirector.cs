﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//セレクト画面での統括
//--------------------------------------------------------------------------
public class SelectDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    void Awake()
    {
        //バトルステージの数を指定
        BattleDirector.stageLimit = 5;

        ClearData clearData = new ClearData().Load();

        //初なら説明文を出す
        if(clearData.isFirsttimePlayGame)
        {
            //チュートリアルへ


            //次回以降説明なし
            clearData.isFirsttimePlayGame = false;
            clearData.Save();   //セーブ
        }
    }

    void Update()
    {
    }
    //--------------------------------------------------------------------------

}
