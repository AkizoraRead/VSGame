﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//--------------------------------------------------------------------------
//機能統括スクリプト
//--------------------------------------------------------------------------
public class OptionDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド
    public static bool isInput;         //入力（有効・無効）

    //よく使う機能などはここに書く
    [HideInInspector]
    public SceneChange  sceneClass;     //シーン移動のクラス
    [HideInInspector]
    public GameEnd      gameEndClass;   //ゲーム(アプリ)終了機能
    [HideInInspector]
    public ScreenTouch  touchClass;     //タップ機能


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        OptionDirector.isInput = true;
        //クラスの設定
        this.sceneClass     = GetComponent<SceneChange>();
        this.gameEndClass   = GetComponent<GameEnd>();
        this.touchClass     = GetComponent<ScreenTouch>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //バトルステージへ変移
    //引数（選択したステージ番号）
    public void BattleSceneChange(int num)
    {
        BattleDirector.stageNum = num;
        this.sceneClass.NextScene("BattleScene");
    }
}
