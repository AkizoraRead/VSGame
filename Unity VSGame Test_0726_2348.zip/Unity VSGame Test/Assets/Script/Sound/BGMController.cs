﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//BGM操作クラス
//--------------------------------------------------------------------------
public class BGMController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    SoundReader soundRederClass;    //音源読み込みクラス
    AudioSource audioS;             //

    bool        isStop;             //BGMが止まっているか

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //コンポーネント接続
        this.soundRederClass = GameObject.Find("SoundDirector").GetComponent<SoundReader>();
        this.audioS = GetComponent<AudioSource>();

        //初期設定
        this.isStop = false;

        this.audioS.loop = true;
        this.audioS.playOnAwake = true;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //BGMの開始
    //引数（BGMの名前）
    public void BGM_Play(string name)
    {
        //クリップ読み込み
        AudioClip audioClip = this.soundRederClass.Sound(name);
        //クリップがなければ処理しない
        if (audioClip == null) { return; }

        this.audioS.Stop(); //停止
        this.audioS.clip = audioClip;
        this.audioS.Play();
    }
    //--------------------------------------------------------------------------
    //BGMの一時停止と再開
    public void BGM_StopOrRestart()
    {
        this.isStop = !this.isStop;
        if (this.isStop)    { this.audioS.Pause(); }    //一時停止
        else                { this.audioS.UnPause(); }  //再開

    }
    //--------------------------------------------------------------------------
    //BGMの音量変更
    //引数（音量 0.0f ～ 1.0f）
    public void BGM_SetVolume(float value)
    {
        this.audioS.volume = value;
    }
    //--------------------------------------------------------------------------
}
