﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラ編集シーンで使われるプレイヤーの処理
//--------------------------------------------------------------------------
public class PlayerCharaCreateController : PlayerBase
{
    //--------------------------------------------------------------------------
    //フィールド


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        base.SetPlayerBase();    //保存データ読み込み＆セット
    }

    void Update()
    {
        MotionChange(Motion.WALK);
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ボタン操作
    //--------------------------------------------------------------------------
    //キャラ名変更
    //引数（キャラ名）
    public void SetCharaName(string name_)
    {
        if (name_ == "") { name_ = "Player"; }//入力した文字列がなければ Player として登録
        this.param.Name = name_;
    }

    //--------------------------------------------------------------------------
    //キャラ絵切り替え
    public void SetCharaAnim(int num)
    {
        SetAnimType(num);
    }

    //--------------------------------------------------------------------------
    //コマンドを再設定
    //Attack
    //引数（コマンド名）
    public void SetCommandAttack(string name_)
    {
        this.param.AttackCName = name_;
    }
    //--------------------------------------------------------------------------
    //Recover
    //引数（コマンド名）
    public void SetCommandRecover(string name_)
    {
        this.param.RecoverCName = name_;
    }
    //--------------------------------------------------------------------------
    //Enhance
    //引数（コマンド名）
    public void SetCommandEnhance(string name_)
    {
        this.param.EnhanceCName = name_;
    }
    //--------------------------------------------------------------------------
    //パラメータを再設定
    //パラメータレベルアップ
    //引数（コマンドの種類名）
    public void ParamLevelUp(string cName_)
    {
        LevelChange(cName_,true);
    }
    //パラメータレベルダウン
    //引数（コマンドの種類名）
    public void ParamLevelDown(string cName_)
    {
        LevelChange(cName_,false);
    }
    //--------------------------------------------------------------------------
    //セーブ
    public void PlayerDataSave()
    {
        Save();
        this.param.Save("PlayerData");
    }
    //--------------------------------------------------------------------------
}
