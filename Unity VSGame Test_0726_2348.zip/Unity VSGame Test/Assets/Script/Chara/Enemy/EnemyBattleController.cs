﻿using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//バトルシーンでのエネミーの処理
//--------------------------------------------------------------------------
public class EnemyBattleController : EnemyBase , CharaCommand
{
    //--------------------------------------------------------------------------
    //フィールド

    BattleDirector      director;       //シーンでの統括クラス
    CharaUIManager      uiClass;        //キャラごとのUI操作クラス

    

    public bool         isCommand;      //コマンドを実行したかどうか

    int attackCnt;      //攻撃コマンドのカウンタ(連続)
    int recoverCnt;     //回復コマンドのカウンタ(連続)
    int enhanceCnt;     //強化コマンドのカウンタ(連続)
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        base.SetEnemyBase("Enemy1"); //テキストデータ読み込み

        this.director   = GameObject.Find("BattleDirector").GetComponent<BattleDirector>();
        this.uiClass    = GetComponent<CharaUIManager>();

        this.param.target   = GameObject.FindGameObjectWithTag("Player");
        this.param.Hp       = this.param.MaxHp;

        this.isCommand  = true;
        this.attackCnt  = 0;
        this.recoverCnt = 0;
        this.enhanceCnt = 0;
    }

    void Update()
    {
        if(BattleDirector.endState != BattleDirector.EndState.None)         { return; }
        if(BattleDirector.battleTurn != BattleDirector.BattleTurn.Enemy)    
        {
            //アニメーション
            MotionChange(Motion.STAND);
            return;
        }
        if(BattleDirector.turnState != BattleDirector.TurnState.InGame)     { return; }


        if (!this.isCommand) { return; }
        Invoke("Enemy_Activity",1.0f);

        //アニメーション
        MotionChange(Motion.WALK);

        this.isCommand = false;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //登録された攻撃コマンドを実行する
        this.cDataClass.attackCommand.cData[this.param.AttackCName].command(ref this.param);

        this.attackCnt++;

        this.recoverCnt = 0;
        this.enhanceCnt = 0;

        //アニメーション
        MotionChange(Motion.ATTACK);
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.cDataClass.recoverCommand.cData[this.param.RecoverCName].command(ref this.param);

        this.recoverCnt++;

        this.attackCnt  = 0;
        this.enhanceCnt = 0;

        //アニメーション
        MotionChange(Motion.SPELL);
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.cDataClass.enhanceCommand.cData[this.param.EnhanceCName].command(ref this.param);

        this.enhanceCnt++;

        this.attackCnt  = 0;
        this.recoverCnt = 0;

        //アニメーション
        MotionChange(Motion.SPELL);
    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        //HP減少
        this.param.Hp -= param_.Power;

        //ダメージ表示
        Text text   = this.uiClass.CreateText(param_.Power.ToString(), gameObject);
        text.color  = new Color(1.0f, 0.0f, 0.0f);   //文字の色を赤に

        //アニメーション
        MotionChange(Motion.DAMAGE);

        //体力が残っているかチェック
        if (this.param.CheckNoHasHP())
        {
            //アニメーション
            MotionChange(Motion.DESTROY);


            //消滅エフェクト


            //消滅処理
            Invoke("Destroy", 1.0f);

            //クリア判定
            this.director.Invoke("CheckGameClear", 1.1f);

            Debug.Log(gameObject.name + "消滅");
        }
    }
    //--------------------------------------------------------------------------
    //自分への回復処理
    //引数（回復量）
    public void Recover(int value)
    {
        //回復後の体力
        int newHP = this.param.Hp + value;

        //回復後のHPが最大体力を超えていないかチェック
        if (this.param.CheckMaxHP(newHP)) { this.param.Hp = this.param.MaxHp; }
        else { this.param.Hp = newHP; }

        //回復値を表示
        Text text   = this.uiClass.CreateText(value.ToString(), gameObject);
        text.color  = new Color(0.0f, 1.0f, 0.0f);   //文字の色を緑に
    }
    //--------------------------------------------------------------------------
    //コマンドミス
    public void Miss()
    {
        Text text   = this.uiClass.CreateText("ミス", gameObject);
        text.color  = new Color(0.0f, 0.0f, 0.0f);   //文字の色を黒に
    }
    //--------------------------------------------------------------------------
    //消滅処理
    void Destroy()
    {
        Destroy(gameObject);
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //敵の行動ルーチン
    //--------------------------------------------------------------------------
    void Enemy_Activity()
    {
        //レベルごとに行動変更
        switch (this.Level)
        {
            //レベル１
            case 1:    
                Command1();
                break;
            //レベル２
            case 2:
                if (this.param.Hp <= this.param.MaxHp * 0.2f && this.recoverCnt == 0) 
                {
                    Command2(); //回復
                }
                else 
                {
                    Command1(); //攻撃
                }
                break;
            //レベル３
            case 3:
                //経過ターン数毎に変化
                switch (BattleDirector.turnCnt)
                {
                    //１ターン目
                    case 1:
                        Command3(); //強化
                        break;
                    //２ターン目
                    case 2:
                        Command1(); //攻撃
                        break;
                    //３ターン目以降
                    default:
                        //体力が３割 && 前のターンで回復をしていない場合　回復する
                        if (this.param.Hp <= this.param.MaxHp * 0.3f && this.recoverCnt == 0)
                        {
                            Command2(); //回復
                        }
                        //強化している状態なら攻撃
                        else if (this.cDataClass.enhanceCommand.BuffTurn > 0)
                        {
                            Command1(); //攻撃
                        }
                        //強化されてない時は強化
                        else
                        {
                            Command3(); //強化
                        }
                        break;
                }
                break;
        }
    }
    //--------------------------------------------------------------------------

}
