﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//キャラクターに必要なパラメータや関数を格納しておく
//--------------------------------------------------------------------------
public class CharaBase : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //アニメーション
    public enum Motion
    {
        STAND,      //立ちモーション
        WALK,       //歩きモーション
        ATTACK,     //攻撃モーション(物理)
        SPELL,      //呪文モーション(魔法攻撃,回復,強化)
        DAMAGE,     //ダメージモーション
        DESTROY,    //消滅モーション
    }

    //--------------------------------------------------------------------------
    //フィールド
    public Motion   motion; //モーション管理

    public Animator         anim;       //アニメーション
    public SpriteRenderer   sprite;     //絵
    public CharaParameter   param;      //パラメータクラス
    public CharaCommandData cDataClass; //コマンドクラス
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    protected CharaBase()
    {
        this.motion = Motion.STAND;
        this.anim = null;
        this.sprite = null;
        this.param = new CharaParameter();
        this.cDataClass = null;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //セッティング
    //--------------------------------------------------------------------------
    //キャラベースの再設定
    protected void SetCharaBase(string name)
    {
        this.motion     = Motion.STAND;
        this.anim       = null;
        this.sprite     = null;
        if (name != "")
        {
            //保存データを読み込む
            this.param = new CharaParameter().Load(name);
        }
        else
        {
            this.param = new CharaParameter();
        }
        this.cDataClass = new CharaCommandData();   //読み込み作業があるためコンストラクタでは呼び出さない
    }
    //--------------------------------------------------------------------------
    //コンポーネントと変数の設定
    protected virtual void ComponentSetting()
    {
        this.param.myself = gameObject;
        this.sprite = GetComponent<SpriteRenderer>();
        this.anim   = GetComponent<Animator>();
        AnimatorLoad animLoad = new AnimatorLoad();
        this.anim.runtimeAnimatorController = animLoad.GetAnimatorController(this.param.CType,this.param.AnimType);
    }
    //--------------------------------------------------------------------------
    //キャラ絵の切り替え
    public void SetAnimType(int num)
    {
        this.param.AnimType = num;
        AnimatorLoad animLoad = new AnimatorLoad();
        this.anim.runtimeAnimatorController = animLoad.GetAnimatorController(this.param.CType, this.param.AnimType);
        Animation();
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //アニメーション設定
    public void Animation()
    {
        //anim.runtimeAnimatorController = animTable[0];  //絵の指定


        //モーション毎にアニメーション変化
        switch(this.motion)
        {
            case Motion.STAND:  this.anim.SetBool("MyTurn", false);  break;
            case Motion.WALK:   this.anim.SetBool("MyTurn", true);   break;
            case Motion.ATTACK: this.anim.SetTrigger("Attack");      break;
            case Motion.SPELL:  this.anim.SetTrigger("Spell");       break;
            case Motion.DAMAGE: this.anim.SetTrigger("Damage");      break;
            case Motion.DESTROY:this.anim.SetTrigger("Destroy");     break;
        }
    }
    //--------------------------------------------------------------------------
    //モーション変更
    public void MotionChange(Motion motion_)
    {
        //現在のモーションと違えば処理する
        if(this.motion != motion_) 
        { 
            this.motion = motion_;      //変更
            Animation();                //モーションが変わればアニメーションも変更
        } 
        
    }
    //--------------------------------------------------------------------------
}


