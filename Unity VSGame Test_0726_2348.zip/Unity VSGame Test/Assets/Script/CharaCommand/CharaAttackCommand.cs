﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;

//--------------------------------------------------------------------------
//攻撃コマンド
//--------------------------------------------------------------------------
public class CharaAttackCommand : CharaCommandBase
{
    //--------------------------------------------------------------------------
    //フィールド

    //--------------------------------------------------------------------------
    //コンストラクタ
    public CharaAttackCommand()
    {
        string[]str = new string[]{ "通常攻撃", "必中攻撃" };

        this.cdName = str;

        foreach (string name_ in this.cdName)
        {
            this.cData.Add(name_, CommandDataSet(name_, CommandType.Attack));
        }
    }
    //--------------------------------------------------------------------------
    //コマンド処理を設定
    //引数(コマンド名)
    protected override Command CommandSet(string name_)
    {
        Command command_ = null;

        switch (name_)
        {
            case "通常攻撃": command_ = AttackCommand_1; break;
            case "必中攻撃": command_ = AttackCommand_2; break;
            default:
                Debug.LogWarning(name_ + "というコマンドは存在しない\n自動的に1を設定します。");
                command_ = AttackCommand_1;
                break;
        }

        return command_;
    }

    //--------------------------------------------------------------------------
    //攻撃対象のパラメータの取得する
    //引数（攻撃対象のオブジェクト）
    CharaParameter GetTargetParameter(GameObject target)
    {
        CharaParameter param = target.GetComponent<CharaBase>().param;
        //エラー処理
        if (param == null)
        {
            Debug.LogError(target.tag + ":タグに一致するオブジェクトのパラメータが見つかりませんでした。");
        }
        return param;
    }
    //--------------------------------------------------------------------------
    //攻撃対象へのダメージ処理
    //引数（攻撃元のパラメータ情報）
    void TargetDamame(CharaParameter me)
    {

        me.target.GetComponent<CharaCommand>().Damage(me);
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //攻撃コマンドはここに追加していく
    //通常攻撃
    void AttackCommand_1(ref CharaParameter param_)
    {
        this.effectClass = GameObject.Find("Generator").GetComponent<EffectGenerator>();
        //攻撃対象のパラメータの取得する
        CharaParameter enemy = GetTargetParameter(param_.target);

        //当たったかどうか
        int hit = Random.Range(0, 100);
        //成功
        if(hit >= enemy.DodgeRate) 
        {
            //ダメージ処理
            TargetDamame(param_);

            //エフェクトの生成
            GameObject effect = this.effectClass.EffectGenerate("Slash");
            effect.transform.position += param_.target.transform.position;
            effect.transform.localScale = param_.target.transform.localScale;


        }
        //失敗
        else
        {
            param_.target.GetComponent<CharaCommand>().Miss();
            Debug.Log("攻撃ミス！");
        }

        //SE

        Debug.Log("AttackCommand_1 : 実行");
    }

    //必中攻撃
    void AttackCommand_2(ref CharaParameter param_)
    {
        //攻撃対象のパラメータの取得する
        CharaParameter enemy = GetTargetParameter(param_.target);

        //通常の0.7倍の攻撃力で攻撃
        CharaParameter me = param_;
        me.Power_Magnification *= 0.7f; //現在の倍率の70％にする

        //ダメージ処理
        TargetDamame(me);

        //エフェクトの生成
        GameObject effect = this.effectClass.EffectGenerate("Slash");
        effect.transform.position += param_.target.transform.position;
        effect.transform.localScale = param_.target.transform.localScale;

        //SE

        Debug.Log("AttackCommand_2 : 実行");
    }

    //--------------------------------------------------------------------------
}
