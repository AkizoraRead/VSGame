﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//コマンド統括クラス
//--------------------------------------------------------------------------
public class CharaCommandData
{
    //--------------------------------------------------------------------------
    //フィールド

    public CharaAttackCommand  attackCommand;   //攻撃コマンドクラス
    public CharaRecoverCommand recoverCommand;  //回復コマンドクラス
    public CharaEnhanceCommand enhanceCommand;  //強化コマンドクラス

    //--------------------------------------------------------------------------
    //コンストラクタ
    public CharaCommandData()
    {
        this.attackCommand = new CharaAttackCommand();
        this.recoverCommand = new CharaRecoverCommand();
        this.enhanceCommand = new CharaEnhanceCommand();
    }
    //--------------------------------------------------------------------------
}
