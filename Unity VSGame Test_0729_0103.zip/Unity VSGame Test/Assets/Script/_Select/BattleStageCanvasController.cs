﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//ステージ選択ボタンの操作
//--------------------------------------------------------------------------
public class BattleStageCanvasController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    ClearData   clearData;      //クリアデータ
    Button[]    stageButton;    //ステージ選択のボタン
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        //クリアデータを読み込む
        this.clearData = new ClearData().Load();


        //ボタンの設定
        this.stageButton = new Button[BattleDirector.stageLimit];
        for (int i = 0; i < BattleDirector.stageLimit; i++)
        {
            this.stageButton[i] = transform.GetChild(i).GetComponent<Button>();

            //ボタンのテキスト表示
            Text text = this.stageButton[i].transform.GetChild(0).transform.GetComponent<Text>();

            string msg = "";
            if (i != 0) { msg = "ステージ" + i + "\n\n"; }
            else { msg = "チュートリアル" + "\n\n"; }   //チュートリアルステージの場合

            text.text = msg;


            //ボタンの有効・無効化

            int flagNum = i - 1;
            if (flagNum < 1) { continue; }
            //前のステージが未クリアなら無効化
            if (!this.clearData.isStageClear[flagNum]) { this.stageButton[i].interactable = false; }
        }

        gameObject.SetActive(false);
    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
}
