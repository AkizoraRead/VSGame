﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//ロード画面処理
//--------------------------------------------------------------------------
public class LoadCanvasController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド
    [SerializeField] float fadeTime = 1.0f;

    Fade fadeClass; //Fade機能
    Text loadText;  //ロードテキスト
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.loadText = transform.Find("LoadText").GetComponent<Text>();
        this.fadeClass = new Fade(this.loadText.color);

    }

    void Update()
    {
        this.fadeClass.FadeInOut(this.fadeTime);
        this.loadText.color = this.fadeClass.GetColor();
    }
}
