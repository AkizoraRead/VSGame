﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//ボタンクリック時にする処理
//--------------------------------------------------------------------------
public class ButtonClickController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //ボタン入力の種類
    enum TYPE
    {
        Normal = 0, //通常
        Cancel = 1, //キャンセル
        Switch = 2  //切り替え(シーンなど)
    }

    //--------------------------------------------------------------------------
    //フィールド

    SoundDirector   soundClass;     //音制御クラス

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.soundClass = GameObject.Find("SoundDirector").GetComponent<SoundDirector>();
    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ボタンクリック時の処理
    //引数（入力種類の番号）
    public void ButtonClick(int num)
    {
        TYPE type = (TYPE)num;
        //SE名
        string sName = "";

        //TYPEごとに処理
        switch (type)
        {
            case TYPE.Cancel:   sName = "SE_System03"; break;
            case TYPE.Switch:   sName = "SE_System01"; break;
            default:            sName = "SE_System02"; break;
        }

        this.soundClass.seClass.SE_SetVolume(1.0f);
        //クリックSE
        this.soundClass.seClass.SE_Play(sName);

    }
}
