﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//Fade機能
//--------------------------------------------------------------------------
public class Fade
{
    //--------------------------------------------------------------------------
    //Fade状態
    enum FadeState { In,Out};
    //--------------------------------------------------------------------------
    //フィールド

    Color       fadeColor;  //変化するColor
    FadeState   fadeState;  //Fade状態
    //--------------------------------------------------------------------------
    //コンストラクタ
    //引数（FadeするColor）
    public Fade(Color color)
    {
        this.fadeColor  = color;
        this.fadeState = FadeState.In;
    }
    //--------------------------------------------------------------------------
    //FadeIn処理(１フレーム)
    //引数（Fadeする時間）
    public void FadeIn(float fadeTime)
    {
        this.fadeColor -= new Color(0.0f, 0.0f, 0.0f, Time.deltaTime / fadeTime);
    }
    //--------------------------------------------------------------------------
    //FadeOut処理(１フレーム)
    //引数（Fadeする時間）
    public void FadeOut(float fadeTime)
    {
        this.fadeColor += new Color(0.0f, 0.0f, 0.0f, Time.deltaTime / fadeTime);
    }
    //--------------------------------------------------------------------------
    //FadeInOut処理(１フレーム)
    //引数（Fadeする時間）
    public void FadeInOut(float fadeTime)
    {
        if(this.fadeColor.a >= 1.0f)        { this.fadeState = FadeState.In; }
        else if(this.fadeColor.a <= 0.0f)   { this.fadeState = FadeState.Out; }

        if(this.fadeState == FadeState.In)  { FadeIn(fadeTime); }
        else                                { FadeOut(fadeTime); }
    }
    //--------------------------------------------------------------------------
    //Fadeした結果のColorを返す
    public Color GetColor()
    {
        return this.fadeColor;
    }
    //--------------------------------------------------------------------------
}
