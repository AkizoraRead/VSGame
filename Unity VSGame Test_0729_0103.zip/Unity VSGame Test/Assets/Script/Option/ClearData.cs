﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

//クリア済みかどうかのデータ
public class ClearData : SaveData
{
    //--------------------------------------------------------------------------
    //フィールド

    //保存する変数
    public bool     isFirsttimePlayGame;    //このゲームをするのが初めてか
    public bool     isCharaCreate;  //キャラクリエイト画面へ入ったことがあるか
    public bool[]   isStageClear;   //ステージクリア


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    public ClearData()
    {
        this.isFirsttimePlayGame    = true;
        this.isCharaCreate          = true;
        this.isStageClear           = new bool[BattleDirector.stageLimit];    //ステージの数、生成
        for(int i = 0;i < BattleDirector.stageLimit; i++)
        {
            this.isStageClear[i] = false;
        }
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    //引数(スコア)
    public void Save()
    {
        DataSave("ClearData", this);  //スコアデータ保存
    }

    //--------------------------------------------------------------------------
    //ロードしたデータ返す(PlayerPrefから読み込み)
    public ClearData Load()
    {
        //保存してあるデータを受け取る
        ClearData data = new ClearData();
        DataLoad("ClearData", ref data); //

        return data;
    }
    //--------------------------------------------------------------------------
}
