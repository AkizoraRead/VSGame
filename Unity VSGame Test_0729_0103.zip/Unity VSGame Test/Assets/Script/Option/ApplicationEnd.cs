﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplicationEnd : MonoBehaviour
{
    //ゲーム終了（アプリケーション終了）
    public void GameQuit()
    {
        //保存するものはここで処理しておく

        Debug.Log("ゲーム終了");
        Application.Quit();
    }
}
