﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//キャラクリエイト画面での統括
//--------------------------------------------------------------------------
public class CharaCreateDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    SoundDirector soundClass;   //音制御クラス
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        ClearData clearData = new ClearData().Load();

        this.soundClass = GameObject.Find("SoundDirector").GetComponent<SoundDirector>();

        //BGM再生
        this.soundClass.bgmClass.BGM_SetVolume(0.2f);
        this.soundClass.bgmClass.BGM_Play("BGM_CharaCreate01");

        //初回のみ説明あり
        if (clearData.isCharaCreate)
        {
            //チュートリアル処理


            //次回以降説明なし
            clearData.isCharaCreate = false;
            clearData.Save();
        }

    }

    void Update()
    {
        
    }
    //--------------------------------------------------------------------------



}
