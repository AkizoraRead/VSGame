﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//セレクト画面での統括
//--------------------------------------------------------------------------
public class SelectDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    SoundDirector soundClass;     //音制御クラス
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.soundClass = GameObject.Find("SoundDirector").GetComponent<SoundDirector>();
        //バトルステージの数を指定
        BattleDirector.stageLimit = 5;

        ClearData clearData = new ClearData().Load();


        //BGM再生
        this.soundClass.bgmClass.BGM_SetVolume(0.4f);
        this.soundClass.bgmClass.BGM_Play("BGM_Title");
        //初なら説明文を出す
        if (clearData.isFirsttimePlayGame)
        {
            //チュートリアル処理へ


            //次回以降説明なし
            clearData.isFirsttimePlayGame = false;
            clearData.Save();   //セーブ
        }
    }

    void Update()
    {
    }
    //--------------------------------------------------------------------------

}
