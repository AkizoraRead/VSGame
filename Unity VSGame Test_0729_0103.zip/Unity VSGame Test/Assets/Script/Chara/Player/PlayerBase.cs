﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//プレイヤー固有のパラメータや関数
//--------------------------------------------------------------------------
public class PlayerBase : CharaBase
{
    //--------------------------------------------------------------------------
    //フィールド
    [SerializeField] int[] pLevel = new int[] { };

    int[,]      level;      //HPレベル 攻撃力レベル 回避率レベル  それぞれ３段階
    SaveData    saveClass;  //セーブ・ロード機能
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    //引数（ロードをするか）
    public PlayerBase()
    {
        this.pLevel = new int[] { 0, 0, 0 };
        //レベルごとのパラメータ
        this.level = new int[,] 
        {
            {   30, 40, 50},    //HP 
            {   10, 12, 14},    //Power
            {   5,  15, 25}     //DodgeRate
        };
        this.saveClass = new SaveData();
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤーベースの再設定
    protected void SetPlayerBase()
    {
        base.SetCharaBase("PlayerData");    //キャラベース再設定

        PlayerBase pBase = Load();  //保存データの読み込み
        this.pLevel = pBase.pLevel;

        SetParam();                 //パラメータをレベルに合わせる
        ComponentSetting();
    }
    //--------------------------------------------------------------------------
    //キャラの基本パラメータのセット
    public void SetParam()
    {
        this.param.CType        = CharaParameter.CharaType.Player;
        this.param.MaxHp        = this.level[0, this.pLevel[0]]; //HP
        this.param.Power        = this.level[1, this.pLevel[1]]; //Power
        this.param.DodgeRate    = this.level[2, this.pLevel[2]]; //DodgeRate
    }
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    public void Save()
    {
        this.saveClass.DataSave("PlayerBaseData", this);
    }
    //--------------------------------------------------------------------------
    //ロードしたデータ返す(PlayerPrefから読み込み)
    public PlayerBase Load()
    {
        PlayerBase data = gameObject.AddComponent<PlayerBase>();
        this.saveClass.DataLoad("PlayerBaseData", ref data);


        return data;
    }
    //--------------------------------------------------------------------------
    //レベル変更
    //引数（レベルアップするパラメータの種類名,Up(true) or Down(false)）
    public void LevelChange(string cName,bool isUp)
    {
        //変更するパラメータレベルを判定
        int type = 0;
        switch(cName)
        {
            case "HP":          type = 0;    break;
            case "Power":       type = 1;    break;
            case "DodgeRate":   type = 2;    break;
            default:            Debug.Log("レベルアップに失敗しました"); return;
        }

        //レベルアップ
        if (isUp)
        {
            //レベルアップ後が配列範囲内ならレベルアップ
            if (this.pLevel[type] + 1 < this.level.GetLength(1))
            {
                this.pLevel[type]++;
            }
        }
        //レベルダウン
        else
        {
            //レベルダウン後が配列範囲内ならレベルダウン
            if (this.pLevel[type] - 1 >= 0)
            {
                this.pLevel[type]--;
            }
        }


        //パラメータをレベルに合わせる
        SetParam();
    }
    //--------------------------------------------------------------------------
}
