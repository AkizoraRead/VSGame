﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //CharaCreate
        //if (Input.GetKeyDown(KeyCode.A))
        //{
        //    GetComponent<PlayerCharaCreate>().playerBase.CharaDataSave("PlayerData");
        //}
        //if (Input.GetKeyDown(KeyCode.S))
        //{
        //    Debug.Log(GetComponent<PlayerCharaCreate>().playerBase.CharaDataAllLog());
        //    Debug.Log(GetComponent<PlayerCharaCreate>().playerBase.CharaParameter_ToJson());
        //}
        //if (Input.GetKeyDown(KeyCode.D))
        //{
        //    GetComponent<PlayerCharaCreate>().playerBase = new PlayerBase(gameObject);
        //}
        //if (Input.GetKeyDown(KeyCode.F))
        //{
        //    GetComponent<PlayerCharaCreate>().playerBase.CharaLoad("PlayerData", gameObject);
        //    GetComponent<PlayerCharaCreate>().playerBase.ColorChange(GetComponent<PlayerCharaCreate>().playerBase.color);
        //}
        //Battle
        if (Input.GetKeyDown(KeyCode.G))
        {
            GetComponent<CharaCommand>().Command1();
        }
        if (Input.GetKeyDown(KeyCode.H))
        {
            GameObject go = GameObject.FindGameObjectWithTag("Enemy");
            go.GetComponent<CharaCommand>().Command2();
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            GetComponent<PlayerCharaCreateController>().Save();
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            GetComponent<PlayerCharaCreateController>().Load();
        }
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
        }
        if (Input.GetKeyDown(KeyCode.Alpha6))
        {
        }
    }


}
