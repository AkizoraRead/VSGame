﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//ダメージ表示UI
//--------------------------------------------------------------------------
public class DamageTextController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    public float timeLimit = 1.0f;  //表示時間
    float   moveSpeed;

    Fade    fadeClass;              //Fade機能
    Text    text;                   //ダメージテキスト
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.moveSpeed  = Screen.height / 8.0f;
        this.text       = GetComponent<Text>();
        this.fadeClass  = new Fade(this.text.color);
    }

    // Update is called once per frame
    void Update()
    {
        //移動処理
        transform.position += new Vector3(0.0f, Time.deltaTime * this.moveSpeed, 0.0f);

        //フェードアウト処理
        this.fadeClass.FadeIn(this.timeLimit);
        this.text.color = this.fadeClass.GetColor();


        if (this.text.color.a <= 0.0f)
        {
            //消滅処理
            Destroy(gameObject);
        }
    }
    //--------------------------------------------------------------------------
}
