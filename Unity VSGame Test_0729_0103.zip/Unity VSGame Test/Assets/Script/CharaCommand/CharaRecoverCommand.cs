﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//回復コマンド
//--------------------------------------------------------------------------
public class CharaRecoverCommand : CharaCommandBase
{
    //--------------------------------------------------------------------------
    //フィールド
    
    int buffTurn;  //効果ターン数

    //--------------------------------------------------------------------------
    //プロパティ
    //効果ターン数
    public int BuffTurn
    {
        get { return this.buffTurn; }
        private set { this.buffTurn = value; }
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    public CharaRecoverCommand()
    {
        //コマンド名
        this.cdName = new string[]{"即時回復","継続回復"};

        //コマンド名の分だけ設定
        foreach (string name_ in this.cdName)
        {
            this.cData.Add(name_, CommandDataSet(name_, CommandType.Recover));
        }

        this.BuffTurn = 0;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コマンド処理を設定
    //引数(コマンド名)
    protected override Command CommandSet(string name_)
    {
        Command command_ = null;

        switch (name_)
        {
            case "即時回復": command_ = RecoverCommand_1; break;
            case "継続回復": command_ = RecoverCommand_2; break;
            default:
                Debug.LogWarning(name_ + "というコマンドは存在しない\n自動的に1を設定します。");
                command_ = RecoverCommand_1;
                break;
        }


        return command_;
    }
    //--------------------------------------------------------------------------
    //効果の時間のチェック(効果継続：true)
    //引数（詠唱元のパラメータ情報）
    public void CheckRecoverTurn(ref CharaParameter param_)
    {
        //ないなら処理せず
        if (this.BuffTurn <= 0){ return; }

        //登録されたコマンドを実行
        this.cData[param_.RecoverCName].command(ref param_);

        //継続ターン減少
        this.BuffTurn--;

        return;
    }
    //--------------------------------------------------------------------------
    //自分への回復処理
    //引数（パラメータ,回復量）
    void MeRecover(CharaParameter me , int value)
    {

        me.myself.GetComponent<CharaCommand>().Recover(value);
    }


    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //回復コマンドはここに追加していく
    //即時回復
    //引数（詠唱元のパラメータ情報）
    void RecoverCommand_1(ref CharaParameter param_)
    {
        //最大体力の0.4倍を回復
        float recoverValuef = (float)param_.MaxHp * 0.4f;

        //ログテキスト追加
        BattleDirector.battleLog.Add(param_.Name + " は " + param_.RecoverCName + " を唱えた！");

        //回復処理
        MeRecover(param_, (int)recoverValuef);

        //エフェクト生成
        GameObject effect           = this.effectClass.EffectGenerate("Sparkle");
        effect.transform.position   += param_.myself.transform.position;
        effect.transform.localScale = param_.myself.transform.localScale;


        //SE
        this.seClass.SE_Play("SE_Battle_Spell01");

        Debug.Log("RecoverCommand_1 : 実行");
    }
    //--------------------------------------------------------------------------
    //継続回復
    //引数（詠唱元のパラメータ情報）
    void RecoverCommand_2(ref CharaParameter param_)
    {
        //ターン中
        if (BattleDirector.turnState == BattleDirector.TurnState.InGame)
        {
            //効果時間設定
            this.buffTurn = 3;  //3ターン

            //ログテキスト追加
            BattleDirector.battleLog.Add(param_.Name + " は " + param_.RecoverCName + " を唱えた！");

            //エフェクト生成
            GameObject effect           = this.effectClass.EffectGenerate("GreenLight");
            effect.transform.position   += param_.myself.transform.position;
            effect.transform.localScale = param_.myself.transform.localScale;


            //SE
            this.seClass.SE_Play("SE_Battle_Spell01");

        }
        //ターンエンド時
        else if (BattleDirector.turnState == BattleDirector.TurnState.End)
        {
            //回復処理
            //最大体力の二割を回復
            float recoverValuef = (float)param_.MaxHp * 0.2f;

            //回復処理
            MeRecover(param_, (int)recoverValuef);

            //エフェクト生成
            GameObject effect           = this.effectClass.EffectGenerate("Sparkle");
            effect.transform.position   += param_.myself.transform.position;
            effect.transform.localScale = param_.myself.transform.localScale;

        }

        Debug.Log("RecoverCommand_2 : 実行");
    }
    //--------------------------------------------------------------------------
}
