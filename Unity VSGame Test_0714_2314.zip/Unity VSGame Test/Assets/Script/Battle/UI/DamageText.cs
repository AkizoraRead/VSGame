﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//ダメージ表示UI
//--------------------------------------------------------------------------
public class DamageText : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    public float timeLimit = 0.0f;  //表示時間
    float delta;                    //経過時間計測

    Text text;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.delta = 0.0f;

        this.text = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        //時間計測
        if(this.timeLimit > this.delta)
        {
            this.delta += Time.deltaTime;

            //移動処理
            transform.position += new Vector3(0.0f, this.delta, 0.0f);
            //フェードアウト処理
            FadeOut();
        }
        else
        {
            //消滅処理
            Destroy(gameObject);
        }
    }
    //--------------------------------------------------------------------------
    //フェードアウト処理
    void FadeOut()
    {
        float a = Time.deltaTime / this.timeLimit;
        this.text.color -= new Color(0.0f, 0.0f, 0.0f, a);
    }
}
