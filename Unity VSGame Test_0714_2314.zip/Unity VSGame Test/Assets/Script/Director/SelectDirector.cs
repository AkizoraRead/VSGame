﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectDirector : MonoBehaviour
{
    // Start is called before the first frame update
    void Awake()
    {
        //バトルステージの数を指定
        BattleDirector.stageLimit = 5;
    }

    // Update is called once per frame
    void Update()
    {
    }

}
