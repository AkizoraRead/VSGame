﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharaCreateDirector : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //現在のプレイヤーデータをロード

        //反映


    }

    // Update is called once per frame
    void Update()
    {
        
    }




}
