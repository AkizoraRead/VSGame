﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//キャラクターに必要なパラメータや関数を格納しておく
//--------------------------------------------------------------------------
public class CharaBase
{
    //--------------------------------------------------------------------------
    //フィールド

    public SpriteRenderer   sprite;     //絵
    public CharaParameter   param;      //パラメータクラス
    public CharaCommandData cDataClass; //コマンドクラス
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コンストラクタ
    protected CharaBase()
    {
        this.sprite     = null;

        this.param      = new CharaParameter();
        this.cDataClass = new CharaCommandData();
    }
    protected CharaBase(string name)
    {
        this.sprite     = null;

        this.param      = new CharaParameter();
        //保存データを読み込む
        this.param = this.param.CharaParameterLoad(name);

        this.cDataClass = new CharaCommandData();

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //セッティング
    //--------------------------------------------------------------------------
    //コンポーネントと変数の設定
    protected virtual void ComponentSetting(GameObject go)
    {
        this.param.myself = go;
        this.sprite = go.GetComponent<SpriteRenderer>();
    }
    //--------------------------------------------------------------------------



}


