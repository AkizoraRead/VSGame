﻿using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//バトルシーンでのエネミーの処理
//--------------------------------------------------------------------------
public class EnemyBattle : MonoBehaviour , CharaCommand
{
    //--------------------------------------------------------------------------
    //フィールド

    BattleDirector      director;       //シーンでの統括クラス
    CharaUIManager      uiClass;        //キャラごとのUI操作クラス
    public EnemyBase    enemyBase;      //エネミーの変数などのデータ

    //値が変化する可能性があるパラメータ
    public CharaParameter param;

    public bool         isCommand;      //コマンドを実行したかどうか

    int attackCnt;      //攻撃コマンドのカウンタ
    int recoverCnt;     //回復コマンドのカウンタ
    int enhanceCnt;     //強化コマンドのカウンタ
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {

        this.director   = GameObject.Find("BattleDirector").GetComponent<BattleDirector>();
        this.uiClass    = GetComponent<CharaUIManager>();
        this.enemyBase  = new EnemyBase(gameObject, "Enemy1");

        this.param          = this.enemyBase.param;
        this.param.target   = GameObject.FindGameObjectWithTag("Player");
        this.param.Hp       = this.param.MaxHp;

        this.isCommand  = true;
        this.attackCnt  = 0;
        this.recoverCnt = 0;
        this.enhanceCnt = 0;
    }

    void Update()
    {
        if(BattleDirector.endState != BattleDirector.EndState.None) { return; }
        if(BattleDirector.battleTurn != BattleDirector.BattleTurn.Enemy) { return; }
        if(BattleDirector.turnState != BattleDirector.TurnState.InGame) { return; }


        if (!this.isCommand) { return; }
        Invoke("EnemyAttack_Activity",1.0f);
        this.isCommand = false;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //登録された攻撃コマンドを実行する
        this.enemyBase.cDataClass.attackCommand.cData[this.param.AttackCName].command(ref this.param);

    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.enemyBase.cDataClass.recoverCommand.cData[this.param.RecoverCName].command(ref this.param);

    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.enemyBase.cDataClass.enhanceCommand.cData[this.param.EnhanceCName].command(ref this.param);

    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        //HP減少
        this.param.Hp -= param_.Power;

        //ダメージ表示
        Text text   = this.uiClass.CreateText(param_.Power.ToString(), gameObject);
        text.color  = new Color(1.0f, 0.0f, 0.0f);   //文字の色を赤に

        //体力が残っているかチェック
        if (this.param.CheckNoHasHP())
        {
            //消滅処理
            Invoke("Destroy", 1.0f);

            //クリア判定
            this.director.Invoke("CheckGameClear", 1.1f);

            Debug.Log(gameObject.name + "消滅");
        }
    }
    //--------------------------------------------------------------------------
    //自分への回復処理
    //引数（回復量）
    public void Recover(int value)
    {
        //回復後の体力
        int newHP = this.param.Hp + value;

        //回復後のHPが最大体力を超えていないかチェック
        if (this.param.CheckMaxHP(newHP)) { this.param.Hp = this.param.MaxHp; }
        else { this.param.Hp = newHP; }

        //回復値を表示
        Text text   = this.uiClass.CreateText(value.ToString(), gameObject);
        text.color  = new Color(0.0f, 1.0f, 0.0f);   //文字の色を緑に
    }
    //--------------------------------------------------------------------------
    //コマンドミス
    public void Miss()
    {
        Text text   = this.uiClass.CreateText("ミス", gameObject);
        text.color  = new Color(0.0f, 0.0f, 0.0f);   //文字の色を黒に
    }
    //--------------------------------------------------------------------------
    //破壊処理
    void Destroy()
    {
        Destroy(gameObject);
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //敵の行動ルーチン
    //--------------------------------------------------------------------------
    //レッド(攻撃タイプ)
    void EnemyAttack_Activity()
    {
        
        switch (this.enemyBase.Level)
        {
            //レベル１
            case 1:    
                Command1();
                break;
            //レベル２
            case 2:
                if (this.param.Hp <= this.param.MaxHp * 0.2f) { Command2(); }
                else { Command1(); }
                break;
            //レベル３
            case 3:
                switch (BattleDirector.turnCnt)
                {
                    case 1:
                        Command3();
                        break;
                    case 2:
                        Command1();
                        break;
                    default:
                        if (this.enemyBase.cDataClass.enhanceCommand.BuffTurn > 0)
                        {
                            Command1();
                        }
                        else
                        {
                            if (this.param.Hp <= this.param.MaxHp * 0.3f) { Command2(); }
                            else { Command3(); }
                        }
                        break;
                }
                break;
        }
    }
    //--------------------------------------------------------------------------
    //グリーン(体力タイプ)
    //--------------------------------------------------------------------------
    //ブルー(回避タイプ)
    //--------------------------------------------------------------------------
    //ボス(総合的)
    //--------------------------------------------------------------------------

}
