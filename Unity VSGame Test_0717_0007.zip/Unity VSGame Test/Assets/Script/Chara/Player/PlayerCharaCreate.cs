﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラ編集シーンで使われるプレイヤーの処理
//--------------------------------------------------------------------------
public class PlayerCharaCreate : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    public PlayerBase playerBase;   //プレイヤーの変数などのデータ

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.playerBase = new PlayerBase(gameObject);
    }

    void Update()
    {
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ボタン操作
    //--------------------------------------------------------------------------
    //キャラ名変更
    //引数（キャラ名）
    public void CharaNameChange(string name_)
    {
        if (name_ == "") { name_ = "Player"; }//入力した文字列がなければ Player として登録
        this.playerBase.param.Name = name_;
    }

    //--------------------------------------------------------------------------
    //キャラの色替え
    //赤
    public void ColorChange_Red()
    {
        this.playerBase.ColorChange(new Color(1f, 0f, 0f,1f));

        Debug.Log("色を赤に変更");
    }
    //--------------------------------------------------------------------------
    //青
    public void ColorChange_Blue()
    {
        this.playerBase.ColorChange(new Color(0f, 0f, 1f,1f));
        Debug.Log("色を青に変更");
    }
    //--------------------------------------------------------------------------
    //緑
    public void ColorChange_Green()
    {
        this.playerBase.ColorChange(new Color(0f, 1f, 0f,1f));
        Debug.Log("色を緑に変更");
    }

    //--------------------------------------------------------------------------
    //コマンドを再設定
    //Attack
    //引数（コマンド名）
    public void CommandChange_Attack(string name_)
    {
        this.playerBase.param.AttackCName = name_;
    }
    //--------------------------------------------------------------------------
    //Recover
    //引数（コマンド名）
    public void CommandChange_Recover(string name_)
    {
        this.playerBase.param.RecoverCName = name_;
    }
    //--------------------------------------------------------------------------
    //Enhance
    //引数（コマンド名）
    public void CommandChange_Enhance(string name_)
    {
        this.playerBase.param.EnhanceCName = name_;
    }
    //--------------------------------------------------------------------------
    //パラメータを再設定
    //パラメータレベルアップ
    //引数（コマンドの種類名）
    public void ParamLevelUp(string cName_)
    {
        this.playerBase.LevelChange(cName_,true);
    }
    //パラメータレベルダウン
    //引数（コマンドの種類名）
    public void ParamLevelDown(string cName_)
    {
        this.playerBase.LevelChange(cName_,false);
    }
    //--------------------------------------------------------------------------
    //セーブ
    public void PlayerDataSave()
    {
        this.playerBase.Save();
        this.playerBase.param.Save("PlayerData");
    }
    //--------------------------------------------------------------------------
}
