﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラクターのHPゲージのUI管理
//--------------------------------------------------------------------------
public class HPGauge : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド


    HPGaugeSlider charaHPGauge;

    int     maxValue;           //HP初期値（上限）
    int     charaHPValue;       //HP(更新)
    int     charaHPValuePre;    //1フレーム前
    bool    isRedReduce;

    public GameObject target;  //参照元（キャラクター）

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    struct HPGaugeSlider
    {
        //緑ゲージ
        public Slider hpGauge;  //キャラクターのHPを表すゲージ（即座）
        //赤ゲージ
        public Slider redGauge; //受けたダメージ分を表すゲージ（ゆっくり減少）
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        //キャラクタの最大HPを受け取る 
        //タグによってどのクラスから受け取るか決める
        if (this.target.tag == "Player")
        {
            this.maxValue = this.target.GetComponent<PlayerBattle>().param.MaxHp;
        }
        else if (this.target.tag == "Enemy")
        {
            this.maxValue = this.target.GetComponent<EnemyBattle>().param.MaxHp;
        }
        //エラー処理
        else
        {
            Debug.LogError(this.target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
        }


        this.charaHPValue       = this.maxValue;
        this.charaHPValuePre    = this.maxValue;

        this.charaHPGauge = SetHPGaugeSlider(); 

        this.isRedReduce = false;

    }

    // Update is called once per frame
    void Update()
    {
        //HP更新
        CharaHPValue_Update();

        //HP減少作業中かチェック
        if (this.isRedReduce) { RedGaugeReduce(); }

        //記録されたHPの値と比較する
        //HPが減った場合
        if (this.charaHPValue < this.charaHPValuePre) { HPGaugeReduce(); }
        //HPが増えた場合
        else if (this.charaHPValue > this.charaHPValuePre) { HPGaugeAdd(); }

        //HP記録
        this.charaHPValuePre = this.charaHPValue;

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //HP増加
    public void HPGaugeAdd()
    {
        //ゲージの値を変更
        this.charaHPGauge.hpGauge.value     = this.charaHPValue;    //緑ゲージ
        this.charaHPGauge.redGauge.value    = this.charaHPValue;    //赤ゲージ

        this.isRedReduce = false;
    }

    //--------------------------------------------------------------------------
    //HP減少
    public void HPGaugeReduce()
    {
        //ゲージの値を削減
        this.charaHPGauge.hpGauge.value = this.charaHPValue;   //緑ゲージ

        //赤ゲージの処理をさせるフラグをたたせる
        this.isRedReduce = true;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //HPゲージの設定
    HPGaugeSlider SetHPGaugeSlider()
    {
        HPGaugeSlider hpSlider;
        //接続
        hpSlider.hpGauge    = transform.GetComponent<Slider>();
        hpSlider.redGauge   = transform.Find("RedGauge").GetComponent<Slider>();

        //初期化
        //HPゲージ
        hpSlider.hpGauge.maxValue   = this.maxValue;
        hpSlider.hpGauge.value      = this.maxValue;

        //赤ゲージ
        hpSlider.redGauge.maxValue  = this.maxValue;
        hpSlider.redGauge.value     = this.maxValue;

        return hpSlider;
    }
    //--------------------------------------------------------------------------
    //赤ゲージを徐々に減少させていく処理
    void RedGaugeReduce()
    {
        //現在の赤ゲージの量
        float redValue = this.charaHPGauge.redGauge.value;

        //赤ゲージの量がキャラのHPより大きければ処理
        if (redValue > this.charaHPValue)
        {
            //減少する処理
            redValue -= Time.deltaTime * 20.0f; //1秒に10ずつ減少

            this.charaHPGauge.redGauge.value = redValue;
        }
        else
        {
            this.isRedReduce = false;   //処理終了
        }

    }

    //--------------------------------------------------------------------------
    //キャラクタの最新のHPの値を更新する処理
    void CharaHPValue_Update()
    {
        if(this.target == null) { Destroy(gameObject); return; }

        //タグによってどのクラスから受け取るか決める
        if (this.target.tag == "Player")
        {
            this.charaHPValue = this.target.GetComponent<PlayerBattle>().param.Hp;
        }
        else if (this.target.tag == "Enemy")
        {
            this.charaHPValue = this.target.GetComponent<EnemyBattle>().param.Hp;
        }
        //エラー処理
        else
        {
            Debug.LogError(this.target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
        }
    }
    //--------------------------------------------------------------------------
}
