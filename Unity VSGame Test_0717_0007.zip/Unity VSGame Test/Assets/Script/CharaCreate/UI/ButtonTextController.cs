﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラクリエイトでのボタンのテキストUI
//--------------------------------------------------------------------------
public class ButtonTextController : MonoBehaviour
{
    //--------------------------------------------------------------------------

    //表示するテキストの種類
    enum TextType
    {
        None,
        HP,
        Power,
        DodgeRate,
        CommandAttack,
        CommandRecover,
        CommandEnhance,
    }
    //--------------------------------------------------------------------------
    //フィールド

    [SerializeField]　TextType   type = TextType.None;
    [SerializeField]　int        cNum = 0;
    Text buttonText;                //変えるテキスト
    PlayerCharaCreate playerClass;  //プレイヤーのデータ

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        //プレイヤーのデータを指定
        this.playerClass = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerCharaCreate>();

        //子要素のテキストを指定
        this.buttonText = transform.Find("Text").GetComponent<Text>();

        TextChange();
    }

    void Update()
    {
        //テキストの更新
        TextChange();
    }

    //--------------------------------------------------------------------------
    //ボタンのテキスト設定
    void TextChange()
    {
        string text = "";
        //タイプごとに受け取るテキストを決める
        switch (this.type)
        {
            case TextType.HP:               text = this.playerClass.playerBase.param.GetHPLog();        break;
            case TextType.Power:            text = this.playerClass.playerBase.param.GetPowerLog();     break;
            case TextType.DodgeRate:        text = this.playerClass.playerBase.param.GetDodgeRateLog(); break;
            case TextType.CommandAttack:    text = CommandText(); break;
            case TextType.CommandRecover:   text = CommandText(); break;
            case TextType.CommandEnhance:   text = CommandText(); break;
            default:                        text = "エラー";   break;
        }

        text = text.Replace("\n", "");  //改行を削除
        this.buttonText.text = text;
    }
    //--------------------------------------------------------------------------
    //コマンド名取得
    string CommandText()
    {
        string text = "";
        switch (this.type)
        {
            //攻撃コマンド名取得
            case TextType.CommandAttack:
                switch (this.cNum)
                {
                    //キャラに設定されているコマンド名
                    case -1:
                        text = this.playerClass.playerBase.param.GetAttackCommandNameLog(); 
                        break;
                    //コマンドに登録されているコマンド名
                    default:
                        text = this.playerClass.playerBase.cDataClass.attackCommand.cdName[this.cNum]; 
                        break;
                }
                break;
            //回復コマンド名取得
            case TextType.CommandRecover: 
                switch (this.cNum)
                {
                    //キャラに設定されているコマンド名
                    case -1:
                        text = this.playerClass.playerBase.param.GetRecoverCommandNameLog();
                        break;
                    //コマンドに登録されているコマンド名
                    default:
                        text = this.playerClass.playerBase.cDataClass.recoverCommand.cdName[this.cNum];
                        break;
                }
                break;
            //強化コマンド名取得
            case TextType.CommandEnhance:
                switch (this.cNum)
                {
                    //キャラに設定されているコマンド名
                    case -1:
                        text = this.playerClass.playerBase.param.GetEnhanceCommandNameLog();
                        break;
                    //コマンドに登録されているコマンド名
                    default:
                        text = this.playerClass.playerBase.cDataClass.enhanceCommand.cdName[this.cNum];
                        break;
                }
                break;
            //エラー
            default: text = "エラー"; break;
        }
        return text;
    }
    //--------------------------------------------------------------------------
}
