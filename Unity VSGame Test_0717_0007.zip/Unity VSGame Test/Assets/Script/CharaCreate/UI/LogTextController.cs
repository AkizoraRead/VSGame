﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//説明のテキストUI
//--------------------------------------------------------------------------
public class LogTextController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    Text textUI;    //変化するテキストオブジェクト
    [SerializeField] string cType = "";

    CharaCommandData cDataClass;    //コマンドクラス

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.textUI = transform.Find("LogText").GetComponent<Text>();
        this.cDataClass = new CharaCommandData();
    }

    // Update is called once per frame
    void Update()
    {
        CommandTextDraw(this.cType);
    }

    //--------------------------------------------------------------------------
    //表示するコマンドテキストログの種類を変える
    //引数（コマンドの種類）
    public void CommandTypeChange(string cType_)
    {
        this.cType = cType_;
        //内容を変更
        //CommandTextDraw(cType_);
    }
    //--------------------------------------------------------------------------
    //ログテキストを変更する
    //引数（表示したいコマンドの種類）
    void CommandTextDraw(string cType_)
    {
        string msg = "";

        switch(cType_)
        {
            case "Chara":   msg = GetLogText_Chara();       break;     //プレイヤーに登録されたコマンドの説明
            case "Attack":  msg = GetLogText_AttackAll();   break;     //すべての攻撃コマンドの説明
            case "Recover": msg = GetLogText_RecoverAll();  break;     //すべての回復コマンドの説明
            case "Enhance": msg = GetLogText_EnhanceAll();  break;     //すべての強化コマンドの説明
            default:break;
        }

        this.textUI.text = msg;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //コマンドごとのテキスト表示処理
    //Playerのコマンドをすべて返す
    string GetLogText_Chara()
    {
        string log = "";

        //プレイヤーのキャラデータを取得
        PlayerBase playerBase = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerCharaCreate>().playerBase;

        //プレイヤーに登録されたコマンド名をもとに説明を受け取る
        //AttackCommand
        string cName = playerBase.param.AttackCName;
        log += GetLogText_Attack(cName);

        //RecoverCommand
        cName = playerBase.param.RecoverCName;
        log += GetLogText_Recover(cName);


        //EnhanceCommand
        cName = playerBase.param.EnhanceCName;
        log += GetLogText_Enhance(cName);

        //ログ表示
        return log;
    }

    //--------------------------------------------------------------------------
    //AttackCommandのすべてのコマンド説明を返す
    string GetLogText_AttackAll()
    {
        string log = "";

        //登録されたコマンド名の分ループ
        foreach ( string cName_ in this.cDataClass.attackCommand.cData.Keys)
        {
            log += GetLogText_Attack(cName_);
        }
        return log;
    }
    //--------------------------------------------------------------------------
    //RecoverCommandのすべてのコマンド説明を返す
    string GetLogText_RecoverAll()
    {
        string log = "";

        //登録されたコマンド名の分ループ
        foreach ( string cName_ in this.cDataClass.recoverCommand.cData.Keys)
        {
            log += GetLogText_Recover(cName_);
        }
        return log;
    }
    //--------------------------------------------------------------------------
    //EnhanceCommandのすべてのコマンド説明を返す
    string GetLogText_EnhanceAll()
    {
        string log = "";

        //登録されたコマンド名の分ループ
        foreach ( string cName_ in this.cDataClass.enhanceCommand.cData.Keys)
        {
            log += GetLogText_Enhance(cName_);
        }
        return log;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //個別のコマンド説明を返す
    //--------------------------------------------------------------------------
    //AttackCommandの説明を返す
    //引数（コマンド名）
    string GetLogText_Attack(string cName_)
    {
        string log = "";

        //ログ入力
        log = cDataClass.attackCommand.GetCommandLog(cName_);

        return log;
    }

    //--------------------------------------------------------------------------
    //RecoverCommandの説明を返す
    //引数（コマンド名）
    string GetLogText_Recover(string cName_)
    {
        string log = "";

        //ログ入力
        log = cDataClass.recoverCommand.GetCommandLog(cName_);

        return log;
    }

    //--------------------------------------------------------------------------
    //EnhanceCommandの説明を返す
    //引数（コマンド名）
    string GetLogText_Enhance(string cName_)
    {
        string log = "";

        //ログ入力
        log = cDataClass.enhanceCommand.GetCommandLog(cName_);

        return log;
    }
    //--------------------------------------------------------------------------
}
