﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//強化コマンド
//--------------------------------------------------------------------------
public class CharaEnhanceCommand : CharaCommandBase
{
    //--------------------------------------------------------------------------
    //フィールド

    int buffTurn;   //効果時間
    
    //--------------------------------------------------------------------------
    //プロパティ
    //効果時間
    public int BuffTurn
    {
        get { return this.buffTurn; }
        private set { this.buffTurn = value; }
    }


    //--------------------------------------------------------------------------
    //コンストラクタ
    public CharaEnhanceCommand()
    {
        string[] str = { "攻撃力強化", "回避率強化"};

        this.cdName = str;

        foreach (string name_ in this.cdName)
        {
            this.cData.Add(name_, CommandDataSet(name_, CommandType.Enhance));
        }

        this.BuffTurn = 0;
    }

    //--------------------------------------------------------------------------
    //コマンド処理を設定
    //引数(コマンド名)
    protected override Command CommandSet(string name_)
    {
        Command command_ = null;

        switch (name_)
        {
            case "攻撃力強化": command_ = EnhanceCommand_1; break;
            case "回避率強化": command_ = EnhanceCommand_2; break;
            default:
                Debug.LogWarning(name_ + "というコマンドは存在しない\n自動的に1を設定します。");
                command_ = EnhanceCommand_1;
                break;
        }

        return command_;
    }

    //--------------------------------------------------------------------------
    //効果の時間のチェック(効果継続：true)
    public bool CheckEnhanceTurn(ref CharaParameter param_)
    {
        //ないなら処理せず
        if (this.BuffTurn <= 0) { return false; }

        this.BuffTurn--;

        //効果が切れたか
        if(this.BuffTurn == 0)
        {
            //パラメータ倍率を戻す
            param_.Power_Magnification      = 1.0f;
            param_.DodgeRate_Magnification  = 1.0f;
        }

        return true;
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //強化コマンドはここに追加していく
    //攻撃強化
    void EnhanceCommand_1(ref CharaParameter param_)
    {
        this.effectClass = GameObject.Find("Generator").GetComponent<EffectGenerator>();

        //強化中でなければ強化
        if (this.BuffTurn == 0)
        {
            param_.Power_Magnification = 1.5f;  //1.5倍
        }
        this.BuffTurn = 3;  //ターン終了時に１減るので実質２ターン

        //エフェクトの生成
        GameObject effect = this.effectClass.EffectGenerate("RedLight");
        effect.transform.position   += param_.myself.transform.position;
        effect.transform.localScale = param_.myself.transform.localScale;

        Debug.Log("EnhanceCommand_1 : 実行");
    }

    //回避率強化
    void EnhanceCommand_2(ref CharaParameter param_)
    {
        this.effectClass = GameObject.Find("Generator").GetComponent<EffectGenerator>();

        //強化中でなければ強化
        if (this.BuffTurn == 0)
        {
            param_.DodgeRate_Magnification = 1.5f;  //1.5倍
        }
        this.BuffTurn = 3;  //ターン終了時に１減るので実質２ターン

        //エフェクトの生成
        GameObject effect = this.effectClass.EffectGenerate("RedLight");
        effect.transform.position += param_.myself.transform.position;
        effect.transform.localScale = param_.myself.transform.localScale;


        Debug.Log("EnhanceCommand_2 : 実行");
    }
    void EnhanceCommand_3(ref CharaParameter param_)
    {



        Debug.Log("EnhanceCommand_3 : 実行");
    }
    //--------------------------------------------------------------------------
}
