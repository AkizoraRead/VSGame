﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBattle : PlayerBase
{
    public PlayerBattle(GameObject go) : base(go)
    {

    }
}
