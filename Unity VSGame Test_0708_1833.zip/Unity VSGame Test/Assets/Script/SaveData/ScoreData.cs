﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

//ハイスコアの保存
public class ScoreData
{
    public int[] stageScore = new int[5];

    public void StageScoreSave(int score)
    {
        //登録された値より大きければスコア更新
        if (this.stageScore[BattleDirector.stageNum] < score)
        {
            this.stageScore[BattleDirector.stageNum] = score;
            Debug.Log("ステージスコアを更新しました:Stage" + BattleDirector.stageNum);
        }
        else
        {
            Debug.Log("ステージスコアを更新しません:Stage" + BattleDirector.stageNum);
        }
    }

    //--------------------------------------------------------------------------
    //セーブ
    //--------------------------------------------------------------------------
    //Json形式にpublic,[SerializeField]の変数を変換
    public string ScoreData_ToJson()
    {
        return JsonUtility.ToJson(this);
    }
    //--------------------------------------------------------------------------
    //セーブ(PlayerPrefに保存)
    //引数(格納するデータ名)
    public void ScoreDataSave(string name)
    {
        PlayerPrefs.SetString(name, ScoreData_ToJson());
        PlayerPrefs.Save();
        Debug.Log("保存完了");
    }

    //--------------------------------------------------------------------------
    //ロード(PlayerPrefから読み込み)
    public ScoreData ScoreDataLoad(string name)
    {

        //nameという名のデータが保存されているか
        if (PlayerPrefs.HasKey(name))
        {
            //上書き
            var data = PlayerPrefs.GetString(name);
            JsonUtility.FromJsonOverwrite(data, this);
            Debug.Log("ロード成功:" + name);
            return this;
        }
        else
        {
            Debug.LogWarning(name + "という名のデータは保存されていませんでした。");
            return new ScoreData();
        }
        //セッティング(読み込みだけでは変わらない部分を初期化する)
    }
    //--------------------------------------------------------------------------
}
