﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//--------------------------------------------------------------------------
//エフェクトの管理・生成
//--------------------------------------------------------------------------
public class EffectGenerator : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //設定用のエフェクトの構造体
    [System.Serializable]
    public struct EffectData
    {
        public string name;
        public GameObject effectObj;
    }
    //--------------------------------------------------------------------------
    //フィールド

    [SerializeField]　EffectData[] effectData = null;

    //エフェクトを格納
    Dictionary<string, GameObject> effectTable;

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.effectTable = new Dictionary<string, GameObject>();

        foreach (EffectData data in this.effectData)
        {
            SetEffectTable(data);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //エフェクトを登録する
    //引数（エフェクトの構造体）
    void SetEffectTable(EffectData data)
    {
        this.effectTable[data.name] = data.effectObj;
    }
    //--------------------------------------------------------------------------
    //エフェクト生成
    //引数（生成したいエフェクト名）
    public GameObject EffectGenerate(string name)
    {
        return Instantiate(this.effectTable[name]) as GameObject;
    }
    //--------------------------------------------------------------------------

}
