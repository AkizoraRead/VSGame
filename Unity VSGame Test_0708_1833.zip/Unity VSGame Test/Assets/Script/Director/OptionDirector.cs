﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//--------------------------------------------------------------------------
//機能統括スクリプト
//--------------------------------------------------------------------------
public class OptionDirector : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    //よく使う機能などはここに書く
    [HideInInspector]
    public SceneChange  sceneClass;     //シーン移動のクラス
    [HideInInspector]
    public GameEnd      gameEndClass;   //ゲーム(アプリ)終了機能


    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        //クラスの設定
        this.sceneClass     = GetComponent<SceneChange>();
        this.gameEndClass   = GetComponent<GameEnd>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
