﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラ編集シーンで使われるプレイヤーの処理
//--------------------------------------------------------------------------
public class PlayerCharaCreateController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    public PlayerBase playerBase;   //プレイヤーの変数などのデータ

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.playerBase = new PlayerBase(gameObject);
    }

    void Update()
    {
        this.playerBase.MotionChange(CharaBase.Motion.WALK);
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //ボタン操作
    //--------------------------------------------------------------------------
    //キャラ名変更
    //引数（キャラ名）
    public void SetCharaName(string name_)
    {
        if (name_ == "") { name_ = "Player"; }//入力した文字列がなければ Player として登録
        this.playerBase.param.Name = name_;
    }

    //--------------------------------------------------------------------------
    //キャラ絵切り替え
    public void SetCharaAnim(int num)
    {
        this.playerBase.SetAnimType(num);
    }

    //--------------------------------------------------------------------------
    //コマンドを再設定
    //Attack
    //引数（コマンド名）
    public void SetCommandAttack(string name_)
    {
        this.playerBase.param.AttackCName = name_;
    }
    //--------------------------------------------------------------------------
    //Recover
    //引数（コマンド名）
    public void SetCommandRecover(string name_)
    {
        this.playerBase.param.RecoverCName = name_;
    }
    //--------------------------------------------------------------------------
    //Enhance
    //引数（コマンド名）
    public void SetCommandEnhance(string name_)
    {
        this.playerBase.param.EnhanceCName = name_;
    }
    //--------------------------------------------------------------------------
    //パラメータを再設定
    //パラメータレベルアップ
    //引数（コマンドの種類名）
    public void ParamLevelUp(string cName_)
    {
        this.playerBase.LevelChange(cName_,true);
    }
    //パラメータレベルダウン
    //引数（コマンドの種類名）
    public void ParamLevelDown(string cName_)
    {
        this.playerBase.LevelChange(cName_,false);
    }
    //--------------------------------------------------------------------------
    //セーブ
    public void PlayerDataSave()
    {
        this.playerBase.Save();
        this.playerBase.param.Save("PlayerData");
    }
    //--------------------------------------------------------------------------
}
