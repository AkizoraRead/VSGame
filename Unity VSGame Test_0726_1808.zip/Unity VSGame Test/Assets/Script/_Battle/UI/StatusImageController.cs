﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラクタのバフなどのステータスを表示する
//--------------------------------------------------------------------------
public class StatusImageController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //設定用の画像の構造体
    [System.Serializable]
    public struct ImageData
    {
        public string  name;            //登録名
        public Sprite  spriteData;      //絵
    }
    //--------------------------------------------------------------------------
    //フィールド

    [SerializeField]
    ImageData[]         imageData = null;   //ステータス画像の構造体

    //ステータス画像を格納
    Dictionary<string, Sprite> imageTable;

    public GameObject   target;         //参照元
    CharaParameter      param;          //ターゲットのパラメータ
    CharaCommandData    cDataClass;     //キャラクタのコマンド情報
    Image[]             images;         //表示のためのImage

    int[]               preBuffTurn;    //バフターン
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.imageTable = new Dictionary<string, Sprite>();
        foreach (ImageData data in this.imageData)
        {
            SetImageTable(data);
        }

        this.param      = GetParam();
        this.cDataClass = GetCData();

        this.preBuffTurn = new int[] { 0, 0 };  // 0:回復コマンド　1:強化コマンド

        //子要素分設定
        this.images = new Image[transform.childCount];
        for (int i = 0; i < transform.childCount; i++)
        {
            this.images[i] = transform.GetChild(i).GetComponent<Image>();
        }

        //画像設定
        this.images[0].sprite = this.imageTable[param.RecoverCName];
        this.images[1].sprite = this.imageTable[param.EnhanceCName];


        //非表示にする
        for (int i = 0; i < transform.childCount; i++)
        {
            this.images[i].enabled = false;
        }

    }

    // Update is called once per frame
    void Update()
    {
        //処理するかどうか
        if (!CheckStatus()) { return; }

        //回復ステータスのチェック
        if(this.cDataClass.recoverCommand.BuffTurn > 0) 
        {
            //ステータス表示　回復
            this.images[0].enabled = true;
        }
        else
        {
            //非表示
            this.images[0].enabled = false;
        }
        //強化ステータスのチェック
        if (this.cDataClass.enhanceCommand.BuffTurn > 0) 
        {
            //ステータス表示　強化
            this.images[1].enabled = true;
        }
        else
        {
            //非表示
            this.images[1].enabled = false;
        }
    }

    //--------------------------------------------------------------------------
    //コマンドクラスの取得
    CharaCommandData GetCData()
    {
        //プレイヤーの場合
        if (this.target.tag == "Player")
        {
            return this.target.GetComponent<PlayerBattleController>().playerBase.cDataClass;
        }
        //エネミーの場合
        else if(this.target.tag == "Enemy")
        {
            return this.target.GetComponent<EnemyBattleController>().enemyBase.cDataClass;
        }
        //エラー処理
        else
        {
            Debug.LogError(target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
            return null;
        }
    }
    //--------------------------------------------------------------------------
    //パラメータの取得
    CharaParameter GetParam()
    {
        //パラメータの設定
        if (this.target.tag == "Player")
        {
            return this.target.GetComponent<PlayerBattleController>().param;
        }
        else if (this.target.tag == "Enemy")
        {
            return this.target.GetComponent<EnemyBattleController>().param;
        }
        //エラー処理
        else
        {
            Debug.LogError(target.tag + ":タグに一致するオブジェクトが見つかりませんでした。");
            return null;
        }
    }
    //--------------------------------------------------------------------------
    //画像の登録
    //引数（ステータス画像の構造体）
    void SetImageTable(ImageData data)
    {
        this.imageTable[data.name] = data.spriteData;
    }
    //--------------------------------------------------------------------------
    //ステータス変化をチェックするタイミングか返す(true:処理する)
    bool CheckStatus()
    {
        //ゲーム中のみ処理
        if (BattleDirector.battleTurn == BattleDirector.BattleTurn.None) { return false; }

        return true;
    }
    //--------------------------------------------------------------------------
}
