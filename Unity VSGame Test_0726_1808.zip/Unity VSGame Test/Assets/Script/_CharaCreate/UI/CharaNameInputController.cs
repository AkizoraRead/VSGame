﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//キャラクタの名前入力に使用するクラス
//--------------------------------------------------------------------------
public class CharaNameInputController : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    InputField input;                                   //テキスト入力
    [SerializeField] PlayerCharaCreateController player = null;   //名前を変えるクラス

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.input = GetComponent<InputField>();

        this.input.text = "";
        this.input.text = this.player.playerBase.param.Name;
        this.input.characterLimit = 8;  //文字数制限
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //--------------------------------------------------------------------------
    //キャラネームに反映
    public void CharaNameInput()
    {

        this.player.SetCharaName(this.input.text);
    }
    //--------------------------------------------------------------------------
}
