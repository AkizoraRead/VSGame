﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//--------------------------------------------------------------------------
//Fadeするテキスト
//--------------------------------------------------------------------------
public class FadeText : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //フィールド

    Text text;          //Fadeするテキスト
    Fade fadeClass;     //Fade機能クラス
    [SerializeField] float fadeTime = 1.0f; //Fade処理時間

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.text = GetComponent<Text>();
        this.fadeClass = new Fade(this.text.color);
    }

    void Update()
    {
        this.fadeClass.FadeInOut(this.fadeTime);
        this.text.color = this.fadeClass.GetColor();
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
