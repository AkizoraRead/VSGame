﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPGauge : MonoBehaviour
{
    //--------------------------------------------------------------------------
    //キャラクターのHPゲージのUI管理
    //--------------------------------------------------------------------------
    struct HPGaugeSlider
    {
        //緑ゲージ
        public Slider hpGauge;  //キャラクターのHPを表すゲージ（即座）
        //赤ゲージ
        public Slider redGauge; //受けたダメージ分を表すゲージ（ゆっくり減少）
    }

    //--------------------------------------------------------------------------


    HPGaugeSlider charaHPGauge;

    int maxValue;   //HP初期値（上限）
    int charaHPValue;    //HP(更新)
    bool isRedReduce;

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.maxValue = 0;  //キャラクタの最大HPを受け取る
        this.charaHPValue = 0;

        this.charaHPGauge = SetHPGaugeSlider(); //

        this.isRedReduce = false;

    }

    // Update is called once per frame
    void Update()
    {
        //
        if (this.isRedReduce) { RedGaugeReduce(); }

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //HP増加
    public void HPGaugeAdd()
    {
        //キャラのHP更新
        CharaHPValue_Update();
        //ゲージの値を変更
        this.charaHPGauge.hpGauge.value = this.charaHPValue;      //緑ゲージ
        this.charaHPGauge.redGauge.value = this.charaHPValue;     //赤ゲージ
    }

    //--------------------------------------------------------------------------
    //HP減少
    public void HPGaugeReduce()
    {
        //キャラのHP更新
        CharaHPValue_Update();

        //ゲージの値を削減
        this.charaHPGauge.hpGauge.value = this.charaHPValue;   //緑ゲージ
        //赤ゲージの処理をさせるフラグをたたせる
        this.isRedReduce = true;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //HPゲージの設定
    HPGaugeSlider SetHPGaugeSlider()
    {
        HPGaugeSlider hpSlider;
        //接続
        hpSlider.hpGauge = transform.GetComponent<Slider>();
        hpSlider.redGauge = transform.Find("RedGauge").GetComponent<Slider>();

        //初期化
        //HPゲージ
        hpSlider.hpGauge.maxValue = this.maxValue;
        hpSlider.hpGauge.value = this.maxValue;

        //赤ゲージ
        hpSlider.redGauge.maxValue = this.maxValue;
        hpSlider.redGauge.value = this.maxValue;

        return hpSlider;
    }
    //--------------------------------------------------------------------------
    //赤ゲージを徐々に減少させていく処理
    void RedGaugeReduce()
    {
        //キャラのHP更新
        CharaHPValue_Update();

        //現在の赤ゲージの量
        int redValue = (int)this.charaHPGauge.redGauge.value;

        //赤ゲージの量がキャラのHPより大きければ処理
        if (redValue > this.charaHPValue)
        {
            //減少する処理
            redValue--; //1ずつ減少
            this.charaHPGauge.redGauge.value = redValue;
        }
        else
        {
            this.isRedReduce = false;   //処理終了
        }

    }

    //--------------------------------------------------------------------------
    //キャラクタの最新のHPの値を更新する処理
    void CharaHPValue_Update()
    {
        this.charaHPValue = 0;
    }
    //--------------------------------------------------------------------------
}
