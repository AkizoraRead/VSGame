﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    GameObject menuObj; //メニューに使うObject


    // Start is called before the first frame update
    void Start()
    {
        //接続
        this.menuObj = GameObject.Find("MenuCanvas");
    }

    // Update is called once per frame
    void Update()
    {


    }

    //メニューで行えるボタンの処理
    //メニューモードのON:OFF
    public void Menu(bool isFlag)
    {
        //ゲーム中のみ処理
        if (!BattleDirector.isGaming) { return; }

        BattleDirector.isMenu = isFlag;
        this.menuObj.SetActive(isFlag);
    }

    //
}
