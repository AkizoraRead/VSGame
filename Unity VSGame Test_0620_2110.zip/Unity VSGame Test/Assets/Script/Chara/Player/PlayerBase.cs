﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBase : CharaBase
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤー固有のパラメータや関数
    //--------------------------------------------------------------------------
    //コンストラクタ
    public PlayerBase(GameObject go)
    {
        //初期化
        this.CType = CharaType.Player;
        ComponentSetting(go);
    }

    //--------------------------------------------------------------------------
    //キャラの色変更
    public void ColorChange(Color color_)
    {
        this.color = color_;
        this.sprite.color = color;
    }

    //--------------------------------------------------------------------------

}
