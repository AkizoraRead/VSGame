﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBattle : MonoBehaviour, CharaCommand
{
    public PlayerBase playerBase;   //プレイヤーの変数などのデータ

    //バトルシーンでのみ使用する変数
    //値が変化する可能性があるパラメータ
    public CharaParameter param;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    void Start()
    {
        this.playerBase = new PlayerBase(gameObject);
        this.playerBase.CharaLoad("PlayerData", gameObject);    //プレイヤーのデータをロード、変数を反映

        this.param = this.playerBase.param;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.S)) { Debug.Log(this.param.CharaParameterLog()); }   

    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //攻撃対象を選択
    public void SetTarget(GameObject enemy)
    {
        this.param.target = enemy;
    }

    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //実行されるコマンド
    //--------------------------------------------------------------------------
    //攻撃
    public void Command1()
    {
        //ターゲットが指定されていない場合、自動的に検出した敵を選択する
        if(this.param.target == null) { SetTarget(GameObject.FindGameObjectWithTag("Enemy")); }

        //登録された攻撃コマンドを実行する
        this.playerBase.cDataClass.attackCommand.cData[this.playerBase.AttackCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //回復
    public void Command2()
    {
        //登録された回復コマンドを実行する
        this.playerBase.cDataClass.recoverCommand.cData[this.playerBase.RecoverCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //強化
    public void Command3()
    {
        //登録された強化コマンドを実行する
        this.playerBase.cDataClass.enhanceCommand.cData[this.playerBase.EnhanceCName].command(ref this.param);
    }

    //--------------------------------------------------------------------------
    //自分へのダメージ処理
    //引数（ダメージ元のパラメータ情報）
    public void Damage(CharaParameter param_)
    {
        this.param.Hp -= param_.Power;


        if(this.param.Hp <= 0)
        {
            //ゲームオーバー処理
        }
    }
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
}
