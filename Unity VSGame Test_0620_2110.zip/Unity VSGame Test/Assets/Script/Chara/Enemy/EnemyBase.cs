﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : CharaBase
{
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    //プレイヤー固有のパラメータや関数
    //--------------------------------------------------------------------------
    //コンストラクタ
    public EnemyBase(GameObject go)
    {
        //初期化
        this.CType = CharaType.Enemy;
        ComponentSetting(go);
    }

    //--------------------------------------------------------------------------

}
