﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleDirector : MonoBehaviour
{
    //ターンの状況
    public enum BattleTurn
    {
        None,       //どちらでもない
        Player,     //プレイヤー
        Enemy,      //エネミー
    }

    public static BattleTurn battleTurn;    //ターンの状況
    public static int stageNum;             //ステージ番号
    public static bool isGaming;            //ゲーム中か
    public static bool isMenu;              //メニューを開いているか






    //バトルシーンで一番最初に処理する
    void Awake()
    {
        //初期処理が終わるまでターンは動かさない
        BattleDirector.battleTurn = BattleTurn.None;

        //ステージ設定
        switch (BattleDirector.stageNum)
        {
            case 0: break;  //チュートリアル
            case 1: break;
            case 2: break;
            case 3: break;
            default:break;  //エラー処理
        }

    }

    // Update is called once per frame
    void Update()
    {
    }

    //バトルシーン最初に行うべき処理

    //ステージデータをロード(エネミーについてやラウンド数など)

    //BGMをロード

    //背景をロード

    //チュートリアル
}
